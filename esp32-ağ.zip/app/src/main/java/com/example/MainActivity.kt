package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Bluetooth
import androidx.compose.material.icons.outlined.Code
import androidx.compose.material.icons.outlined.Router
import androidx.compose.material.icons.outlined.Wifi
import androidx.compose.material.icons.rounded.Bluetooth
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.Router
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.model.ConnectionState
import com.example.ui.Esp32UiState
import com.example.ui.Esp32ViewModel
import com.example.ui.screens.BluetoothDevicesScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.Esp32CodeScreen
import com.example.ui.screens.WifiNetworksScreen
import com.example.ui.theme.Esp32AgTheme
import com.example.ui.theme.MonoFontFamily

const val ROUTE_DASHBOARD = "dashboard"
const val ROUTE_WIFI = "wifi_networks"
const val ROUTE_BLUETOOTH = "bluetooth_devices"
const val ROUTE_ESP32_CODE = "esp32_code"

private data class NavTab(
  val route: String,
  val label: String,
  val selectedIcon: ImageVector,
  val unselectedIcon: ImageVector,
  val testTag: String,
)

private val appTabs =
  listOf(
    NavTab(
      route = ROUTE_DASHBOARD,
      label = "Durum",
      selectedIcon = Icons.Rounded.Router,
      unselectedIcon = Icons.Outlined.Router,
      testTag = "nav_tab_dashboard",
    ),
    NavTab(
      route = ROUTE_WIFI,
      label = "Wi-Fi",
      selectedIcon = Icons.Rounded.Wifi,
      unselectedIcon = Icons.Outlined.Wifi,
      testTag = "nav_tab_wifi",
    ),
    NavTab(
      route = ROUTE_BLUETOOTH,
      label = "Bluetooth",
      selectedIcon = Icons.Rounded.Bluetooth,
      unselectedIcon = Icons.Outlined.Bluetooth,
      testTag = "nav_tab_bluetooth",
    ),
    NavTab(
      route = ROUTE_ESP32_CODE,
      label = "ESP32 Kodu",
      selectedIcon = Icons.Rounded.Code,
      unselectedIcon = Icons.Outlined.Code,
      testTag = "nav_tab_code",
    ),
  )

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      Esp32AgTheme {
        Esp32AgApp()
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Esp32AgApp(viewModel: Esp32ViewModel = viewModel()) {
  val uiState by viewModel.uiState.collectAsStateWithLifecycle()
  val navController = rememberNavController()
  val backStackEntry by navController.currentBackStackEntryAsState()
  val currentRoute = backStackEntry?.destination?.route ?: ROUTE_DASHBOARD
  val snackbarHostState = remember { SnackbarHostState() }

  LaunchedEffect(uiState.snackbarMessage) {
    val msg = uiState.snackbarMessage
    if (msg != null) {
      snackbarHostState.showSnackbar(msg)
      viewModel.clearSnackbar()
    }
  }

  val navigateToTab: (String) -> Unit = { route ->
    navController.navigate(route) {
      popUpTo(navController.graph.findStartDestination().id) {
        saveState = true
      }
      launchSingleTop = true
      restoreState = true
    }
  }

  BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
    val useRail = maxWidth >= 600.dp

    Scaffold(
      contentWindowInsets = WindowInsets.safeDrawing,
      snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
      topBar = {
        TopAppBar(
          title = {
            Column {
              Text(
                text = stringResource(id = R.string.app_name),
                style = MaterialTheme.typography.titleLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
              val subtitle = buildHeaderSubtitle(uiState)
              Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonoFontFamily),
                color =
                  if (uiState.esp32Status?.staConnected == true) {
                    MaterialTheme.colorScheme.tertiary
                  } else {
                    MaterialTheme.colorScheme.onSurfaceVariant
                  },
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            }
          },
          colors =
            TopAppBarDefaults.topAppBarColors(
              containerColor = MaterialTheme.colorScheme.background,
              titleContentColor = MaterialTheme.colorScheme.onBackground,
            ),
        )
      },
      bottomBar = {
        if (!useRail) {
          NavigationBar(
            modifier = Modifier.navigationBarsPadding(),
            containerColor = MaterialTheme.colorScheme.surface,
          ) {
            appTabs.forEach { tab ->
              val selected = currentRoute == tab.route
              val badgeCount = tabBadgeCount(tab.route, uiState)
              NavigationBarItem(
                selected = selected,
                onClick = { navigateToTab(tab.route) },
                icon = {
                  TabIconWithBadge(
                    icon = if (selected) tab.selectedIcon else tab.unselectedIcon,
                    label = tab.label,
                    badgeCount = badgeCount,
                  )
                },
                label = {
                  Text(
                    text = tab.label,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                  )
                },
                modifier = Modifier.testTag(tab.testTag),
              )
            }
          }
        }
      },
    ) { innerPadding ->
      Row(
        modifier = Modifier.fillMaxSize().padding(innerPadding),
      ) {
        if (useRail) {
          NavigationRail(
            modifier = Modifier.fillMaxHeight(),
            containerColor = MaterialTheme.colorScheme.surface,
          ) {
            appTabs.forEach { tab ->
              val selected = currentRoute == tab.route
              val badgeCount = tabBadgeCount(tab.route, uiState)
              NavigationRailItem(
                selected = selected,
                onClick = { navigateToTab(tab.route) },
                icon = {
                  TabIconWithBadge(
                    icon = if (selected) tab.selectedIcon else tab.unselectedIcon,
                    label = tab.label,
                    badgeCount = badgeCount,
                  )
                },
                label = { Text(tab.label) },
                modifier = Modifier.testTag(tab.testTag),
              )
            }
          }
        }

        Box(modifier = Modifier.weight(1f).fillMaxSize()) {
          AppNavHost(
            navController = navController,
            uiState = uiState,
            viewModel = viewModel,
            navigateToTab = navigateToTab,
          )
        }
      }
    }
  }
}

@Composable
private fun AppNavHost(
  navController: NavHostController,
  uiState: Esp32UiState,
  viewModel: Esp32ViewModel,
  navigateToTab: (String) -> Unit,
) {
  NavHost(
    navController = navController,
    startDestination = ROUTE_DASHBOARD,
    modifier = Modifier.fillMaxSize(),
  ) {
    composable(ROUTE_DASHBOARD) {
      DashboardScreen(
        uiState = uiState,
        onHostInputChange = viewModel::updateHostInput,
        onConnectClick = { viewModel.connectAndSync() },
        onPresetClick = viewModel::selectPresetHost,
        onDiscoverClick = viewModel::discoverEsp32OnNetwork,
        onRefreshStatus = viewModel::refreshStatusOnly,
        onForgetSavedWifi = viewModel::forgetSavedWifi,
        onNavigateToWifi = { navigateToTab(ROUTE_WIFI) },
        onNavigateToBle = { navigateToTab(ROUTE_BLUETOOTH) },
        onNavigateToCode = { navigateToTab(ROUTE_ESP32_CODE) },
        onShowMessage = viewModel::showSnackbar,
      )
    }

    composable(ROUTE_WIFI) {
      WifiNetworksScreen(
        uiState = uiState,
        onScanWifi = { viewModel.scanWifiFromEsp32() },
        onSearchQueryChange = viewModel::updateWifiSearch,
        onToggleSort = viewModel::toggleWifiSort,
        onSaveAndConnectWifi = viewModel::saveAndConnectWifi,
        onGoToDashboard = { navigateToTab(ROUTE_DASHBOARD) },
      )
    }

    composable(ROUTE_BLUETOOTH) {
      BluetoothDevicesScreen(
        uiState = uiState,
        onScanBle = { viewModel.scanBleFromEsp32() },
        onSearchQueryChange = viewModel::updateBleSearch,
        onToggleNamedOnly = viewModel::toggleBleNamedOnly,
        onGoToDashboard = { navigateToTab(ROUTE_DASHBOARD) },
        onShowMessage = viewModel::showSnackbar,
      )
    }

    composable(ROUTE_ESP32_CODE) {
      Esp32CodeScreen(
        inoCode = uiState.esp32InoCode,
        onShowMessage = viewModel::showSnackbar,
      )
    }
  }
}

@Composable
private fun TabIconWithBadge(
  icon: ImageVector,
  label: String,
  badgeCount: Int,
) {
  if (badgeCount > 0) {
    BadgedBox(
      badge = {
        Badge {
          Text(if (badgeCount > 99) "99+" else badgeCount.toString())
        }
      }
    ) {
      Icon(imageVector = icon, contentDescription = label)
    }
  } else {
    Icon(imageVector = icon, contentDescription = label)
  }
}

private fun tabBadgeCount(route: String, uiState: Esp32UiState): Int =
  when (route) {
    ROUTE_WIFI -> uiState.wifiNetworks.size
    ROUTE_BLUETOOTH -> uiState.bleDevices.size
    else -> 0
  }

private fun buildHeaderSubtitle(uiState: Esp32UiState): String {
  val status = uiState.esp32Status
  return when {
    status != null && status.staConnected ->
      "Kayıtlı Wi-Fi IP: ${status.staIp} (${status.savedSsid})"
    status != null ->
      "ESP32 Bağlı (${uiState.activeHost}) • Kayıtlı Wi-Fi: Yok"
    uiState.connectionState is ConnectionState.Connecting ->
      "ESP32 bağlanıyor..."
    else ->
      "ESP32: Bağlı değil • Telefon IP: ${uiState.phoneNetworkInfo.localIp}"
  }
}
