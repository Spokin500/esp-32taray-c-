package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.esp32DataStore: DataStore<Preferences> by
  preferencesDataStore(name = "esp32_ag_prefs")

class Esp32Preferences(private val context: Context) {

  private object Keys {
    val LAST_HOST = stringPreferencesKey("last_host")
    val SAVED_HOSTS = stringPreferencesKey("saved_hosts")
  }

  val lastHostFlow: Flow<String> =
    context.esp32DataStore.data.map { prefs ->
      prefs[Keys.LAST_HOST]?.takeIf { it.isNotBlank() } ?: "192.168.4.1"
    }

  val recentHostsFlow: Flow<List<String>> =
    context.esp32DataStore.data.map { prefs ->
      val raw = prefs[Keys.SAVED_HOSTS].orEmpty()
      val parsed = raw.split("|").map { it.trim() }.filter { it.isNotBlank() }
      val defaults = listOf("192.168.4.1", "esp32net.local")
      (parsed + defaults).distinct().take(6)
    }

  suspend fun saveHost(host: String) {
    val cleaned = host.trim().removePrefix("http://").removePrefix("https://").trimEnd('/')
    if (cleaned.isBlank()) return
    context.esp32DataStore.edit { prefs ->
      prefs[Keys.LAST_HOST] = cleaned
      val existing =
        prefs[Keys.SAVED_HOSTS]
          .orEmpty()
          .split("|")
          .map { it.trim() }
          .filter { it.isNotBlank() }
      val updated = (listOf(cleaned) + existing).distinct().take(6)
      prefs[Keys.SAVED_HOSTS] = updated.joinToString("|")
    }
  }
}
