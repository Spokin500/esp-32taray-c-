package com.example.data

import android.content.Context
import android.net.ConnectivityManager
import android.net.LinkProperties
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import com.example.model.PhoneNetworkInfo
import java.net.Inet4Address
import java.net.InetAddress
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class AndroidNetworkInspector(context: Context) {

  private val connectivityManager =
    context.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

  private val _wifiNetwork = MutableStateFlow<Network?>(null)
  val wifiNetwork: StateFlow<Network?> = _wifiNetwork.asStateFlow()

  private val wifiCallback =
    object : ConnectivityManager.NetworkCallback() {
      override fun onAvailable(network: Network) {
        _wifiNetwork.value = network
      }

      override fun onLost(network: Network) {
        if (_wifiNetwork.value == network) {
          _wifiNetwork.value = findCurrentWifiNetworkFallback()
        }
      }
    }

  init {
    _wifiNetwork.value = findCurrentWifiNetworkFallback()
    runCatching {
      val request =
        NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI).build()
      connectivityManager.registerNetworkCallback(request, wifiCallback)
    }
  }

  @Suppress("DEPRECATION")
  private fun findCurrentWifiNetworkFallback(): Network? {
    val active = connectivityManager.activeNetwork
    if (active != null) {
      val caps = connectivityManager.getNetworkCapabilities(active)
      if (caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true) {
        return active
      }
    }
    return connectivityManager.allNetworks.firstOrNull { net ->
      connectivityManager
        .getNetworkCapabilities(net)
        ?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
    }
  }

  fun getPhoneNetworkInfo(): PhoneNetworkInfo {
    val wifiNet = _wifiNetwork.value ?: findCurrentWifiNetworkFallback()
    val activeNet = wifiNet ?: connectivityManager.activeNetwork
    val caps = activeNet?.let { connectivityManager.getNetworkCapabilities(it) }
    val linkProps: LinkProperties? = activeNet?.let { connectivityManager.getLinkProperties(it) }

    val isWifi = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
    val isCellular = caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true

    val ipv4Link =
      linkProps?.linkAddresses?.firstOrNull { it.address is Inet4Address }
    val localIp = ipv4Link?.address?.hostAddress ?: "Yok"
    val prefixLen = ipv4Link?.prefixLength ?: 24
    val subnetMask = if (localIp != "Yok") prefixToMask(prefixLen) else "-"

    val gatewayIp =
      linkProps?.routes
        ?.firstOrNull { it.isDefaultRoute && it.gateway is Inet4Address }
        ?.gateway
        ?.hostAddress
        ?: linkProps?.routes?.firstOrNull { it.gateway is Inet4Address }?.gateway?.hostAddress
        ?: "-"

    val transportLabel =
      when {
        isWifi -> "Wi-Fi"
        isCellular -> "Mobil Veri"
        activeNet != null -> "Diğer Ağ"
        else -> "Bağlı Değil"
      }

    return PhoneNetworkInfo(
      localIp = localIp,
      gatewayIp = gatewayIp,
      subnetMask = subnetMask,
      transportLabel = transportLabel,
      isWifiConnected = isWifi,
    )
  }

  fun getWifiBroadcastAddress(): InetAddress? {
    val wifiNet = _wifiNetwork.value ?: findCurrentWifiNetworkFallback() ?: return null
    val linkProps = connectivityManager.getLinkProperties(wifiNet) ?: return null
    val ipv4Link = linkProps.linkAddresses.firstOrNull { it.address is Inet4Address } ?: return null
    val addrBytes = ipv4Link.address.address
    val prefix = ipv4Link.prefixLength.coerceIn(0, 32)
    val mask = if (prefix == 0) 0 else (-1 shl (32 - prefix))
    val ipInt =
      ((addrBytes[0].toInt() and 0xFF) shl 24) or
        ((addrBytes[1].toInt() and 0xFF) shl 16) or
        ((addrBytes[2].toInt() and 0xFF) shl 8) or
        (addrBytes[3].toInt() and 0xFF)
    val broadcastInt = ipInt or mask.inv()
    val broadcastBytes =
      byteArrayOf(
        ((broadcastInt ushr 24) and 0xFF).toByte(),
        ((broadcastInt ushr 16) and 0xFF).toByte(),
        ((broadcastInt ushr 8) and 0xFF).toByte(),
        (broadcastInt and 0xFF).toByte(),
      )
    return runCatching { InetAddress.getByAddress(broadcastBytes) }.getOrNull()
  }

  private fun prefixToMask(prefix: Int): String {
    val safePrefix = prefix.coerceIn(0, 32)
    val mask = if (safePrefix == 0) 0 else (-1 shl (32 - safePrefix))
    return "${(mask ushr 24) and 0xFF}.${(mask ushr 16) and 0xFF}.${(mask ushr 8) and 0xFF}.${mask and 0xFF}"
  }
}
