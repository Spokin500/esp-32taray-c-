package com.example.data

import android.content.Context
import android.net.Network
import com.example.model.BleDeviceItem
import com.example.model.BleScanResult
import com.example.model.DiscoveredEsp32
import com.example.model.Esp32Status
import com.example.model.WifiNetworkItem
import com.example.model.WifiScanResult
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.Dns
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

class Esp32Repository(
  private val context: Context,
  private val networkInspector: AndroidNetworkInspector,
) {

  private val baseClient: OkHttpClient =
    OkHttpClient.Builder()
      .connectTimeout(4, TimeUnit.SECONDS)
      .readTimeout(16, TimeUnit.SECONDS)
      .writeTimeout(6, TimeUnit.SECONDS)
      .build()

  private fun clientForHost(host: String): OkHttpClient {
    val wifiNetwork: Network? = networkInspector.wifiNetwork.value
    if (wifiNetwork == null || !isLocalTarget(host)) {
      return baseClient
    }
    return baseClient
      .newBuilder()
      .socketFactory(wifiNetwork.socketFactory)
      .dns(
        object : Dns {
          override fun lookup(hostname: String): List<InetAddress> {
            return runCatching { wifiNetwork.getAllByName(hostname).toList() }
              .getOrElse { Dns.SYSTEM.lookup(hostname) }
          }
        }
      )
      .build()
  }

  private fun isLocalTarget(host: String): Boolean {
    val clean = normalizeHost(host)
    return clean.startsWith("192.168.") ||
      clean.startsWith("10.") ||
      clean.startsWith("172.") ||
      clean.endsWith(".local")
  }

  fun normalizeHost(rawHost: String): String {
    return rawHost
      .trim()
      .removePrefix("http://")
      .removePrefix("https://")
      .trimEnd('/')
  }

  suspend fun fetchStatus(rawHost: String): Result<Esp32Status> =
    withContext(Dispatchers.IO) {
      runCatching {
        val host = normalizeHost(rawHost)
        require(host.isNotBlank()) { "ESP32 IP veya adres boş olamaz." }
        val request = Request.Builder().url("http://$host/api/status").get().build()
        clientForHost(host).newCall(request).execute().use { response ->
          if (!response.isSuccessful) {
            throw IOException("ESP32 yanıt vermedi (HTTP ${response.code})")
          }
          val body = response.body?.string().orEmpty()
          parseStatusJson(JSONObject(body))
        }
      }
    }

  suspend fun scanWifi(rawHost: String): Result<WifiScanResult> =
    withContext(Dispatchers.IO) {
      runCatching {
        val host = normalizeHost(rawHost)
        val request = Request.Builder().url("http://$host/api/wifi").get().build()
        clientForHost(host).newCall(request).execute().use { response ->
          if (!response.isSuccessful) {
            throw IOException("Wi-Fi taraması başarısız (HTTP ${response.code})")
          }
          val body = response.body?.string().orEmpty()
          val json = JSONObject(body)
          val arr = json.optJSONArray("networks")
          val list = buildList {
            if (arr != null) {
              for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                add(
                  WifiNetworkItem(
                    ssid = obj.optString("ssid", ""),
                    bssid = obj.optString("bssid", ""),
                    rssi = obj.optInt("rssi", -100),
                    channel = obj.optInt("channel", 0),
                    encryption = obj.optString("encryption", "Bilinmiyor"),
                    isOpen = obj.optBoolean("is_open", false),
                    isSaved = obj.optBoolean("is_saved", false),
                  )
                )
              }
            }
          }
          WifiScanResult(
            count = json.optInt("count", list.size),
            savedSsid = json.optString("saved_ssid", ""),
            staConnected = json.optBoolean("sta_connected", false),
            staIp = json.optString("sta_ip", "0.0.0.0"),
            networks = list,
          )
        }
      }
    }

  suspend fun scanBle(rawHost: String): Result<BleScanResult> =
    withContext(Dispatchers.IO) {
      runCatching {
        val host = normalizeHost(rawHost)
        val request = Request.Builder().url("http://$host/api/ble").get().build()
        clientForHost(host).newCall(request).execute().use { response ->
          if (!response.isSuccessful) {
            throw IOException("Bluetooth taraması başarısız (HTTP ${response.code})")
          }
          val body = response.body?.string().orEmpty()
          val json = JSONObject(body)
          val arr = json.optJSONArray("devices")
          val list = buildList {
            if (arr != null) {
              for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                add(
                  BleDeviceItem(
                    name = obj.optString("name", ""),
                    mac = obj.optString("mac", ""),
                    rssi = obj.optInt("rssi", -100),
                    hasName = obj.optBoolean("has_name", false),
                    serviceUuid = obj.optString("service_uuid", ""),
                    txPower = obj.optInt("tx_power", -999),
                    hasManufacturerData = obj.optBoolean("has_manufacturer_data", false),
                  )
                )
              }
            }
          }.sortedByDescending { it.rssi }
          BleScanResult(
            count = json.optInt("count", list.size),
            scanDurationSec = json.optInt("scan_duration_sec", 3),
            devices = list,
          )
        }
      }
    }

  suspend fun connectWifi(
    rawHost: String,
    ssid: String,
    password: String,
  ): Result<Esp32Status> =
    withContext(Dispatchers.IO) {
      runCatching {
        val host = normalizeHost(rawHost)
        val form = FormBody.Builder().add("ssid", ssid).add("password", password).build()
        val request = Request.Builder().url("http://$host/api/wifi/connect").post(form).build()
        clientForHost(host).newCall(request).execute().use { response ->
          if (!response.isSuccessful) {
            throw IOException("Wi-Fi kaydedilemedi (HTTP ${response.code})")
          }
          val body = response.body?.string().orEmpty()
          parseStatusJson(JSONObject(body))
        }
      }
    }

  suspend fun forgetWifi(rawHost: String): Result<Esp32Status> =
    withContext(Dispatchers.IO) {
      runCatching {
        val host = normalizeHost(rawHost)
        val emptyBody = FormBody.Builder().build()
        val request = Request.Builder().url("http://$host/api/wifi/forget").post(emptyBody).build()
        clientForHost(host).newCall(request).execute().use { response ->
          if (!response.isSuccessful) {
            throw IOException("Kayıtlı Wi-Fi silinemedi (HTTP ${response.code})")
          }
          val body = response.body?.string().orEmpty()
          parseStatusJson(JSONObject(body))
        }
      }
    }

  suspend fun discoverEsp32(currentHost: String): List<DiscoveredEsp32> =
    withContext(Dispatchers.IO) {
      coroutineScope {
        val udpJob = async { discoverViaUdp() }
        val candidates =
          listOf(normalizeHost(currentHost), "192.168.4.1", "esp32net.local")
            .filter { it.isNotBlank() }
            .distinct()
        val probeJobs =
          candidates.map { candidate ->
            async {
              fetchStatus(candidate).getOrNull()?.let { status ->
                val preferredIp =
                  if (candidate == "192.168.4.1" || !status.staConnected || status.staIp == "0.0.0.0") {
                    candidate
                  } else {
                    status.staIp
                  }
                DiscoveredEsp32(reachIp = preferredIp, status = status)
              }
            }
          }

        val combined = buildList {
          addAll(udpJob.await())
          probeJobs.awaitAll().filterNotNull().forEach { add(it) }
        }
        combined.distinctBy { it.status.macAddress.ifBlank { it.reachIp } }
      }
    }

  private fun discoverViaUdp(): List<DiscoveredEsp32> {
    val found = mutableListOf<DiscoveredEsp32>()
    var socket: DatagramSocket? = null
    try {
      socket = DatagramSocket()
      socket.broadcast = true
      socket.soTimeout = 1300
      networkInspector.wifiNetwork.value?.let { net ->
        runCatching { net.bindSocket(socket) }
      }

      val payload = "ESP32_DISCOVER".toByteArray(Charsets.UTF_8)
      val targets =
        listOfNotNull(
          networkInspector.getWifiBroadcastAddress(),
          runCatching { InetAddress.getByName("255.255.255.255") }.getOrNull(),
          runCatching { InetAddress.getByName("192.168.4.1") }.getOrNull(),
        ).distinct()

      for (target in targets) {
        runCatching {
          val packet = DatagramPacket(payload, payload.size, InetSocketAddress(target, 4210))
          socket.send(packet)
        }
      }

      val buffer = ByteArray(2048)
      val deadline = System.currentTimeMillis() + 1400L
      while (System.currentTimeMillis() < deadline) {
        try {
          val replyPacket = DatagramPacket(buffer, buffer.size)
          socket.receive(replyPacket)
          val text = String(replyPacket.data, 0, replyPacket.length, Charsets.UTF_8)
          val status = parseStatusJson(JSONObject(text))
          val senderIp = replyPacket.address?.hostAddress ?: status.apIp
          found.add(DiscoveredEsp32(reachIp = senderIp, status = status))
        } catch (_: Exception) {
          break
        }
      }
    } catch (_: Exception) {
      // UDP discovery may fail if Wi-Fi is off; HTTP probes handle fallback
    } finally {
      runCatching { socket?.close() }
    }
    return found
  }

  fun loadBundledInoCode(): String {
    return runCatching {
      context.assets.open("esp32_wroom32_scanner.ino").bufferedReader().use { it.readText() }
    }.getOrElse { "// esp32_wroom32_scanner.ino dosyası okunamadı." }
  }

  companion object {
    fun parseStatusJson(json: JSONObject): Esp32Status {
      return Esp32Status(
        board = json.optString("board", "ESP32-WROOM-32 DevKit V1"),
        chipModel = json.optString("chip_model", "ESP32"),
        cpuMhz = json.optInt("cpu_mhz", 240),
        freeHeapBytes = json.optLong("free_heap", 0L),
        uptimeSec = json.optLong("uptime_sec", 0L),
        macAddress = json.optString("mac", "-"),
        apSsid = json.optString("ap_ssid", "ESP32-WROOM-Net"),
        apIp = json.optString("ap_ip", "192.168.4.1"),
        apClients = json.optInt("ap_clients", 0),
        savedSsid = json.optString("saved_ssid", ""),
        staConnected = json.optBoolean("sta_connected", false),
        staStatusText = json.optString("sta_status_text", "Bilinmiyor"),
        staIp = json.optString("sta_ip", "0.0.0.0"),
        staGateway = json.optString("sta_gateway", "0.0.0.0"),
        staSubnet = json.optString("sta_subnet", "0.0.0.0"),
        staDns = json.optString("sta_dns", "0.0.0.0"),
        staRssi = json.optInt("sta_rssi", 0),
        mdnsHost = json.optString("mdns", "esp32net.local"),
      )
    }
  }
}
