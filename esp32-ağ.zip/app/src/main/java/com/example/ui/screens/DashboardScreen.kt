package com.example.ui.screens

import android.content.Intent
import android.provider.Settings
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bluetooth
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.DeveloperBoard
import androidx.compose.material.icons.rounded.Hub
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.Radar
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Router
import androidx.compose.material.icons.rounded.SettingsEthernet
import androidx.compose.material.icons.rounded.Smartphone
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.ConnectionState
import com.example.ui.Esp32UiState
import com.example.ui.components.IpLocationRow
import com.example.ui.components.StatusPill
import com.example.ui.theme.MonoFontFamily

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DashboardScreen(
  uiState: Esp32UiState,
  onHostInputChange: (String) -> Unit,
  onConnectClick: () -> Unit,
  onPresetClick: (String) -> Unit,
  onDiscoverClick: () -> Unit,
  onRefreshStatus: () -> Unit,
  onForgetSavedWifi: () -> Unit,
  onNavigateToWifi: () -> Unit,
  onNavigateToBle: () -> Unit,
  onNavigateToCode: () -> Unit,
  onShowMessage: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  val clipboard = LocalClipboardManager.current
  val status = uiState.esp32Status

  Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
    LazyColumn(
      modifier = Modifier.widthIn(max = 840.dp).fillMaxSize(),
      contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      // 1. Hero Header Banner + Connection Status
      item {
        Card(
          shape = RoundedCornerShape(22.dp),
          colors =
            CardDefaults.cardColors(
              containerColor = MaterialTheme.colorScheme.surface,
            ),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column {
            Box(
              modifier =
                Modifier.fillMaxWidth().height(132.dp)
            ) {
              Image(
                painter = painterResource(id = R.drawable.img_esp32_board_1795537754197),
                contentDescription = "ESP32-WROOM-32 DevKit V1 kart görseli",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
              )
              Box(
                modifier =
                  Modifier.fillMaxSize()
                    .background(
                      Brush.verticalGradient(
                        colors =
                          listOf(
                            Color.Black.copy(alpha = 0.25f),
                            MaterialTheme.colorScheme.surface.copy(alpha = 0.96f),
                          )
                      )
                    )
              )
              Row(
                modifier =
                  Modifier.fillMaxSize().padding(16.dp),
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.SpaceBetween,
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    text = "ESP32-WROOM-32",
                    style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.onSurface,
                  )
                  Text(
                    text = "DevKit V1 • Wi-Fi & BLE Telemetri",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                  )
                }
                val (pillText, pillDot, pillBg, pillFg) =
                  when (val cs = uiState.connectionState) {
                    is ConnectionState.Connected ->
                      Quad(
                        "Bağlı (${cs.host})",
                        MaterialTheme.colorScheme.tertiary,
                        MaterialTheme.colorScheme.tertiaryContainer,
                        MaterialTheme.colorScheme.onTertiaryContainer,
                      )
                    is ConnectionState.Connecting ->
                      Quad(
                        "Bağlanıyor...",
                        MaterialTheme.colorScheme.primary,
                        MaterialTheme.colorScheme.primaryContainer,
                        MaterialTheme.colorScheme.onPrimaryContainer,
                      )
                    is ConnectionState.Error ->
                      Quad(
                        "Bağlantı Hatası",
                        MaterialTheme.colorScheme.error,
                        MaterialTheme.colorScheme.error.copy(alpha = 0.16f),
                        MaterialTheme.colorScheme.error,
                      )
                    is ConnectionState.Disconnected ->
                      Quad(
                        "Bağlı Değil",
                        MaterialTheme.colorScheme.onSurfaceVariant,
                        MaterialTheme.colorScheme.surfaceContainer,
                        MaterialTheme.colorScheme.onSurfaceVariant,
                      )
                  }
                StatusPill(
                  text = pillText,
                  dotColor = pillDot,
                  containerColor = pillBg,
                  contentColor = pillFg,
                )
              }
            }

            Column(
              modifier = Modifier.padding(16.dp),
              verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
              OutlinedTextField(
                value = uiState.hostInput,
                onValueChange = onHostInputChange,
                label = { Text("ESP32 IP Adresi veya mDNS") },
                placeholder = { Text("Örn: 192.168.4.1 veya 192.168.1.48") },
                singleLine = true,
                textStyle =
                  MaterialTheme.typography.bodyLarge.copy(fontFamily = MonoFontFamily),
                leadingIcon = {
                  Icon(
                    imageVector = Icons.Rounded.Router,
                    contentDescription = "ESP32 adresi",
                  )
                },
                trailingIcon = {
                  if (uiState.connectionState is ConnectionState.Connected) {
                    IconButton(
                      onClick = onRefreshStatus,
                      modifier = Modifier.minimumInteractiveComponentSize().testTag("refresh_status_button"),
                    ) {
                      Icon(
                        imageVector = Icons.Rounded.Refresh,
                        contentDescription = "Durumu yenile",
                      )
                    }
                  }
                },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { onConnectClick() }),
                modifier = Modifier.fillMaxWidth().testTag("esp32_host_input"),
              )

              // Hızlı IP Seçenekleri
              FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
              ) {
                uiState.recentHosts.forEach { preset ->
                  val label =
                    when (preset) {
                      "192.168.4.1" -> "192.168.4.1 (AP)"
                      "esp32net.local" -> "esp32net.local"
                      else -> preset
                    }
                  AssistChip(
                    onClick = { onPresetClick(preset) },
                    label = {
                      Text(
                        text = label,
                        style = MaterialTheme.typography.labelSmall,
                      )
                    },
                    modifier = Modifier.testTag("preset_chip_$preset"),
                  )
                }
              }

              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
              ) {
                Button(
                  onClick = onConnectClick,
                  enabled = uiState.connectionState !is ConnectionState.Connecting,
                  modifier =
                    Modifier.weight(1f).heightIn(min = 48.dp).testTag("connect_esp32_button"),
                ) {
                  if (uiState.connectionState is ConnectionState.Connecting) {
                    CircularProgressIndicator(
                      modifier = Modifier.size(18.dp),
                      strokeWidth = 2.dp,
                      color = MaterialTheme.colorScheme.onPrimary,
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Bağlanıyor")
                  } else {
                    Icon(
                      imageVector = Icons.Rounded.Link,
                      contentDescription = null,
                      modifier = Modifier.size(18.dp),
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Bağlan ve Çek")
                  }
                }

                FilledTonalButton(
                  onClick = onDiscoverClick,
                  enabled = !uiState.isDiscovering,
                  modifier =
                    Modifier.weight(1f).heightIn(min = 48.dp).testTag("discover_esp32_button"),
                ) {
                  if (uiState.isDiscovering) {
                    CircularProgressIndicator(
                      modifier = Modifier.size(18.dp),
                      strokeWidth = 2.dp,
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Aranıyor...")
                  } else {
                    Icon(
                      imageVector = Icons.Rounded.Radar,
                      contentDescription = null,
                      modifier = Modifier.size(18.dp),
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Otomatik Bul")
                  }
                }
              }

              AnimatedVisibility(visible = uiState.connectionState is ConnectionState.Error) {
                val errMsg = (uiState.connectionState as? ConnectionState.Error)?.message.orEmpty()
                Surface(
                  color = MaterialTheme.colorScheme.error.copy(alpha = 0.12f),
                  shape = RoundedCornerShape(12.dp),
                  modifier = Modifier.fillMaxWidth(),
                ) {
                  Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                  ) {
                    Text(
                      text = errMsg,
                      style = MaterialTheme.typography.bodySmall,
                      color = MaterialTheme.colorScheme.error,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                      TextButton(
                        onClick = {
                          context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
                        },
                        modifier = Modifier.testTag("open_wifi_settings_button"),
                      ) {
                        Text("Telefon Wi-Fi Ayarları")
                      }
                      TextButton(
                        onClick = onNavigateToCode,
                        modifier = Modifier.testTag("goto_code_from_error_button"),
                      ) {
                        Text("ESP32 Kodunu Gör")
                      }
                    }
                  }
                }
              }

              AnimatedVisibility(visible = uiState.discoveredDevices.isNotEmpty()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                  Text(
                    text = "Ağda Bulunan ESP32 Cihazları",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                  )
                  uiState.discoveredDevices.forEach { found ->
                    Surface(
                      onClick = { onPresetClick(found.reachIp) },
                      color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f),
                      shape = RoundedCornerShape(12.dp),
                      modifier = Modifier.fillMaxWidth(),
                    ) {
                      Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                      ) {
                        Column(modifier = Modifier.weight(1f)) {
                          Text(
                            text = found.status.board,
                            style = MaterialTheme.typography.labelLarge,
                          )
                          Text(
                            text = "IP: ${found.reachIp} • Kayıtlı Wi-Fi: ${found.status.savedSsid.ifBlank { "Yok" }}",
                            style = MaterialTheme.typography.bodySmall.copy(fontFamily = MonoFontFamily),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                          )
                        }
                        Text(
                          text = "Seç",
                          style = MaterialTheme.typography.labelLarge,
                          color = MaterialTheme.colorScheme.primary,
                        )
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }

      // 2. KAYITLI WI-FI IP ADRESİ (ANA ODAK KARTI)
      item {
        val isStaConnected = status?.staConnected == true
        val savedSsid = status?.savedSsid?.takeIf { it.isNotBlank() }
        val savedWifiIp =
          when {
            status == null -> "ESP32 Bağlı Değil"
            isStaConnected -> status.staIp
            savedSsid != null -> "Bağlı değil (0.0.0.0)"
            else -> "Kayıtlı Wi-Fi Yok"
          }

        Card(
          shape = RoundedCornerShape(22.dp),
          colors =
            CardDefaults.cardColors(
              containerColor =
                if (isStaConnected) {
                  MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.45f)
                } else {
                  MaterialTheme.colorScheme.surface
                },
            ),
          border =
            BorderStroke(
              width = 1.5.dp,
              color =
                if (isStaConnected) {
                  MaterialTheme.colorScheme.tertiary
                } else {
                  MaterialTheme.colorScheme.outlineVariant
                },
            ),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = Icons.Rounded.Hub,
                  contentDescription = null,
                  tint =
                    if (isStaConnected) MaterialTheme.colorScheme.tertiary
                    else MaterialTheme.colorScheme.primary,
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = "Kayıtlı Wi-Fi IP Adresi",
                  style = MaterialTheme.typography.titleLarge,
                )
              }
              if (savedSsid != null && status != null) {
                IconButton(
                  onClick = onForgetSavedWifi,
                  enabled = !uiState.isSavingWifi,
                  modifier = Modifier.minimumInteractiveComponentSize().testTag("forget_saved_wifi_button"),
                ) {
                  Icon(
                    imageVector = Icons.Rounded.DeleteOutline,
                    contentDescription = "Kayıtlı Wi-Fi bilgisini unut",
                    tint = MaterialTheme.colorScheme.error,
                  )
                }
              }
            }

            // Büyük Monospace IP Göstergesi
            Surface(
              color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f),
              shape = RoundedCornerShape(16.dp),
              border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
              modifier = Modifier.fillMaxWidth(),
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    text =
                      if (savedSsid != null) {
                        "Kayıtlı Ağ: $savedSsid"
                      } else {
                        "Henüz ESP32'ye kayıtlı Wi-Fi yok"
                      },
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                  )
                  Spacer(modifier = Modifier.height(4.dp))
                  Text(
                    text = savedWifiIp,
                    style =
                      MaterialTheme.typography.displaySmall.copy(
                        fontFamily = MonoFontFamily,
                        fontWeight = FontWeight.Bold,
                      ),
                    color =
                      if (isStaConnected) MaterialTheme.colorScheme.tertiary
                      else MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.testTag("saved_wifi_ip_text"),
                  )
                }
                if (isStaConnected && status != null) {
                  IconButton(
                    onClick = {
                      clipboard.setText(AnnotatedString(status.staIp))
                      onShowMessage("Kayıtlı Wi-Fi IP kopyalandı: ${status.staIp}")
                    },
                    modifier = Modifier.minimumInteractiveComponentSize().testTag("copy_saved_ip_button"),
                  ) {
                    Icon(
                      imageVector = Icons.Rounded.ContentCopy,
                      contentDescription = "Kayıtlı Wi-Fi IP adresini kopyala",
                      tint = MaterialTheme.colorScheme.tertiary,
                    )
                  }
                }
              }
            }

            if (status != null && isStaConnected) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
              ) {
                MetricMiniBox(
                  label = "Ağ Geçidi",
                  value = status.staGateway,
                  modifier = Modifier.weight(1f),
                )
                MetricMiniBox(
                  label = "Alt Ağ Maskesi",
                  value = status.staSubnet,
                  modifier = Modifier.weight(1f),
                )
              }
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
              ) {
                MetricMiniBox(
                  label = "DNS Sunucusu",
                  value = status.staDns,
                  modifier = Modifier.weight(1f),
                )
                MetricMiniBox(
                  label = "Kayıtlı Wi-Fi Sinyali",
                  value = "${status.staRssi} dBm",
                  modifier = Modifier.weight(1f),
                )
              }
            } else {
              OutlinedButton(
                onClick = onNavigateToWifi,
                modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).testTag("pick_wifi_to_save_button"),
              ) {
                Icon(imageVector = Icons.Rounded.Wifi, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Wi-Fi Ağlarından Seç & ESP32'ye Kaydet")
              }
            }
          }
        }
      }

      // 3. NEREDE HANGİ IP VAR? HARİTASI
      item {
        Card(
          shape = RoundedCornerShape(22.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Rounded.SettingsEthernet,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "Nerede Hangi IP Adresi Var?",
                style = MaterialTheme.typography.titleLarge,
              )
            }

            IpLocationRow(
              label = "1. Kayıtlı Wi-Fi Üzerindeki ESP32",
              whereText =
                if (status?.savedSsid?.isNotBlank() == true) {
                  "Ağ: ${status.savedSsid} (${status.staStatusText})"
                } else {
                  "Ev/Ofis Router (STA Modu)"
                },
              ipValue = status?.staIp ?: "-",
              accentColor = MaterialTheme.colorScheme.tertiary,
              onCopy =
                status?.takeIf { it.staConnected }?.let { st ->
                  {
                    clipboard.setText(AnnotatedString(st.staIp))
                    onShowMessage("STA IP kopyalandı: ${st.staIp}")
                  }
                },
              testTag = "copy_map_sta_ip",
            )

            IpLocationRow(
              label = "2. ESP32 Kendi Erişim Noktası (AP)",
              whereText = "Wi-Fi: ${status?.apSsid ?: "ESP32-WROOM-Net"} • Şifre: 12345678",
              ipValue = status?.apIp ?: "192.168.4.1",
              accentColor = MaterialTheme.colorScheme.primary,
              onCopy = {
                val apIp = status?.apIp ?: "192.168.4.1"
                clipboard.setText(AnnotatedString(apIp))
                onShowMessage("AP IP kopyalandı: $apIp")
              },
              testTag = "copy_map_ap_ip",
            )

            IpLocationRow(
              label = "3. Bu Android Telefon",
              whereText =
                "Bağlantı: ${uiState.phoneNetworkInfo.transportLabel} • Ağ Geçidi: ${uiState.phoneNetworkInfo.gatewayIp}",
              ipValue = uiState.phoneNetworkInfo.localIp,
              accentColor = MaterialTheme.colorScheme.secondary,
              onCopy = {
                clipboard.setText(AnnotatedString(uiState.phoneNetworkInfo.localIp))
                onShowMessage("Telefon IP kopyalandı: ${uiState.phoneNetworkInfo.localIp}")
              },
              testTag = "copy_map_phone_ip",
            )
          }
        }
      }

      // 4. Hızlı Geçiş ve ESP32 Donanım Bilgisi
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          Card(
            onClick = onNavigateToWifi,
            shape = RoundedCornerShape(18.dp),
            colors =
              CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f),
              ),
            modifier = Modifier.weight(1f).testTag("quick_card_wifi"),
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              Icon(
                imageVector = Icons.Rounded.Wifi,
                contentDescription = "Wi-Fi Ağları",
                tint = MaterialTheme.colorScheme.primary,
              )
              Spacer(modifier = Modifier.height(8.dp))
              Text(
                text = "${uiState.wifiNetworks.size} Wi-Fi Ağı",
                style = MaterialTheme.typography.titleMedium,
              )
              Text(
                text = "Listeyi gör & tara",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }

          Card(
            onClick = onNavigateToBle,
            shape = RoundedCornerShape(18.dp),
            colors =
              CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f),
              ),
            modifier = Modifier.weight(1f).testTag("quick_card_ble"),
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              Icon(
                imageVector = Icons.Rounded.Bluetooth,
                contentDescription = "Bluetooth Ağları",
                tint = MaterialTheme.colorScheme.secondary,
              )
              Spacer(modifier = Modifier.height(8.dp))
              Text(
                text = "${uiState.bleDevices.size} BLE Cihazı",
                style = MaterialTheme.typography.titleMedium,
              )
              Text(
                text = "Bluetooth listesini gör",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }
        }
      }

      if (status != null) {
        item {
          Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Column(
              modifier = Modifier.padding(16.dp),
              verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = Icons.Rounded.DeveloperBoard,
                  contentDescription = null,
                  tint = MaterialTheme.colorScheme.primary,
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = "ESP32 Donanım Telemetrisi",
                  style = MaterialTheme.typography.titleMedium,
                )
              }
              HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
              InfoPairRow("Çip Modeli", "${status.chipModel} (${status.cpuMhz} MHz)")
              InfoPairRow("ESP32 MAC", status.macAddress)
              InfoPairRow("Boş RAM (Heap)", "${status.freeHeapBytes / 1024} KB")
              InfoPairRow("Çalışma Süresi", formatUptime(status.uptimeSec))
              InfoPairRow("mDNS Adresi", status.mdnsHost)
              InfoPairRow("AP Bağlı Cihaz", "${status.apClients} istemci")
            }
          }
        }
      } else {
        item {
          FilledTonalButton(
            onClick = onNavigateToCode,
            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).testTag("open_esp32_code_cta"),
          ) {
            Icon(imageVector = Icons.Rounded.Code, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Klon ESP32-WROOM-32 Arduino Kodunu Görüntüle")
          }
        }
      }
    }
  }
}

@Composable
private fun MetricMiniBox(
  label: String,
  value: String,
  modifier: Modifier = Modifier,
) {
  Surface(
    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.78f),
    shape = RoundedCornerShape(12.dp),
    modifier = modifier,
  ) {
    Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)) {
      Text(
        text = label,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
      Spacer(modifier = Modifier.height(2.dp))
      Text(
        text = value,
        style = MaterialTheme.typography.labelLarge.copy(fontFamily = MonoFontFamily),
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )
    }
  }
}

@Composable
private fun InfoPairRow(label: String, value: String) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
  ) {
    Text(
      text = label,
      style = MaterialTheme.typography.bodyMedium,
      color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    Text(
      text = value,
      style = MaterialTheme.typography.bodyMedium.copy(fontFamily = MonoFontFamily),
      fontWeight = FontWeight.Medium,
    )
  }
}

private fun formatUptime(seconds: Long): String {
  val hrs = seconds / 3600
  val mins = (seconds % 3600) / 60
  val secs = seconds % 60
  return if (hrs > 0) "${hrs}sa ${mins}dk ${secs}sn" else "${mins}dk ${secs}sn"
}

private data class Quad<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
