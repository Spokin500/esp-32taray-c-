package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.MonoFontFamily

@Composable
fun Esp32CodeScreen(
  inoCode: String,
  onShowMessage: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  val clipboard = LocalClipboardManager.current
  val shareTitle = stringResource(id = R.string.esp32_code_share_title)

  Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
    LazyColumn(
      modifier = Modifier.widthIn(max = 840.dp).fillMaxSize(),
      contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      item {
        Card(
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Image(
              painter = painterResource(id = R.drawable.img_esp32_board_1795537754197),
              contentDescription = "ESP32-WROOM-32 DevKit V1 kurulum görseli",
              contentScale = ContentScale.Crop,
              modifier = Modifier.fillMaxWidth().height(120.dp).clip(RoundedCornerShape(14.dp)),
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Rounded.Build,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "Klon ESP32-WROOM-32 DevKit V1 Ayarları",
                style = MaterialTheme.typography.titleLarge,
              )
            }

            Surface(
              color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f),
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier.fillMaxWidth(),
            ) {
              Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.Top,
              ) {
                Icon(
                  imageVector = Icons.Rounded.WarningAmber,
                  contentDescription = null,
                  tint = MaterialTheme.colorScheme.primary,
                  modifier = Modifier.size(20.dp),
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text =
                    "ÖNEMLİ: Arduino IDE'de Kart olarak \"ESP32 Dev Module\" seçin (\"DOIT ESP32 DEVKIT V1\" seçiliyse Partition Scheme menüsü görünmez). Ardından Araçlar > Partition Scheme ayarını \"Huge APP (3MB No OTA/1MB SPIFFS)\" yapın.",
                  style = MaterialTheme.typography.bodySmall,
                  fontWeight = FontWeight.SemiBold,
                )
              }
            }

            GuideStep("1. USB Sürücüsü (Klon Kart)", "Klon kartlarda genelde CH340 veya CP2102 USB çipi vardır. Port görünmezse CH340 sürücüsü yükleyin.")
            GuideStep("2. Kart & Hız", "Board: \"ESP32 Dev Module\" • Partition Scheme: \"Huge APP (3MB No OTA/1MB SPIFFS)\" • Upload Speed: 115200 seçin.")
            GuideStep("3. BOOT Tuşu İpucu", "Yükleme sırasında konsolda \"Connecting........\" yazarken kartın üzerindeki BOOT tuşuna 2 saniye basılı tutun.")
            GuideStep("4. Telefondan Bağlantı", "ESP32 açılınca \"ESP32-WROOM-Net\" (Şifre: 12345678) Wi-Fi ağı yayınlar. Bağlanıp 192.168.4.1 adresinden tüm ağları çekin veya ev Wi-Fi'nizi kaydedin!")
          }
        }
      }

      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          Button(
            onClick = {
              clipboard.setText(AnnotatedString(inoCode))
              onShowMessage("ESP32 .ino kodu panoya kopyalandı!")
            },
            modifier = Modifier.weight(1f).heightIn(min = 48.dp).testTag("copy_ino_code_button"),
          ) {
            Icon(
              imageVector = Icons.Rounded.ContentCopy,
              contentDescription = null,
              modifier = Modifier.size(18.dp),
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("Kodu Kopyala")
          }

          FilledTonalButton(
            onClick = {
              val intent =
                Intent(Intent.ACTION_SEND).apply {
                  type = "text/plain"
                  putExtra(Intent.EXTRA_SUBJECT, shareTitle)
                  putExtra(Intent.EXTRA_TEXT, inoCode)
                }
              context.startActivity(Intent.createChooser(intent, shareTitle))
            },
            modifier = Modifier.weight(1f).heightIn(min = 48.dp).testTag("share_ino_code_button"),
          ) {
            Icon(
              imageVector = Icons.Rounded.Share,
              contentDescription = null,
              modifier = Modifier.size(18.dp),
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("Kodu Paylaş")
          }
        }
      }

      item {
        Card(
          shape = RoundedCornerShape(18.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Text(
              text = "esp32_wroom32_scanner.ino",
              style = MaterialTheme.typography.labelLarge.copy(fontFamily = MonoFontFamily),
              color = MaterialTheme.colorScheme.primary,
            )
            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            Spacer(modifier = Modifier.height(8.dp))
            Box(
              modifier =
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            ) {
              Text(
                text = inoCode,
                style =
                  MaterialTheme.typography.bodySmall.copy(
                    fontFamily = MonoFontFamily,
                    fontSize = 11.5.sp,
                    lineHeight = 17.sp,
                  ),
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.testTag("esp32_ino_code_viewer"),
              )
            }
          }
        }
      }
    }
  }
}

@Composable
private fun GuideStep(title: String, detail: String) {
  Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
    Text(
      text = title,
      style = MaterialTheme.typography.labelLarge,
      color = MaterialTheme.colorScheme.primary,
    )
    Text(
      text = detail,
      style = MaterialTheme.typography.bodySmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
  }
}
