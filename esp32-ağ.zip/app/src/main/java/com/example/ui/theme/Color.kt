package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// RF Lab / Hardware Telemetry Palette
val CyanElectric = Color(0xFF00E5FF)
val CyanDeep = Color(0xFF008394)
val CyanContainerDark = Color(0xFF00363E)
val CyanContainerLight = Color(0xFFC4F7FF)

val CobaltBle = Color(0xFF6699FF)
val CobaltDeep = Color(0xFF2356C7)
val CobaltContainerDark = Color(0xFF152A55)
val CobaltContainerLight = Color(0xFFDCE5FF)

val EmeraldLink = Color(0xFF00E676)
val EmeraldDeep = Color(0xFF008744)
val EmeraldContainerDark = Color(0xFF063B22)
val EmeraldContainerLight = Color(0xFFC8F7DC)

val AmberWarn = Color(0xFFFFB300)
val CoralError = Color(0xFFFF5252)
val CoralErrorLight = Color(0xFFC62828)

// Dark Surfaces (Obsidian Slate)
val DarkBg = Color(0xFF080F18)
val DarkSurface = Color(0xFF0D1826)
val DarkSurfaceVariant = Color(0xFF162436)
val DarkSurfaceElevated = Color(0xFF1C2D42)
val DarkOutline = Color(0xFF2B415C)
val DarkTextPrimary = Color(0xFFE9F2FA)
val DarkTextSecondary = Color(0xFF9BB0C7)

// Light Surfaces (Crisp Lab White/Slate)
val LightBg = Color(0xFFF3F7FB)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE4ECF4)
val LightOutline = Color(0xFFC1D0E0)
val LightTextPrimary = Color(0xFF0D1B2A)
val LightTextSecondary = Color(0xFF495D73)
