package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AndroidNetworkInspector
import com.example.data.Esp32Preferences
import com.example.data.Esp32Repository
import com.example.model.BleDeviceItem
import com.example.model.ConnectionState
import com.example.model.DiscoveredEsp32
import com.example.model.Esp32Status
import com.example.model.PhoneNetworkInfo
import com.example.model.WifiNetworkItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class Esp32UiState(
  val hostInput: String = "192.168.4.1",
  val activeHost: String = "192.168.4.1",
  val recentHosts: List<String> = listOf("192.168.4.1", "esp32net.local"),
  val connectionState: ConnectionState = ConnectionState.Disconnected,
  val esp32Status: Esp32Status? = null,
  val phoneNetworkInfo: PhoneNetworkInfo =
    PhoneNetworkInfo(
      localIp = "Yok",
      gatewayIp = "-",
      subnetMask = "-",
      transportLabel = "Kontrol ediliyor...",
      isWifiConnected = false,
    ),
  val isDiscovering: Boolean = false,
  val discoveredDevices: List<DiscoveredEsp32> = emptyList(),
  val wifiNetworks: List<WifiNetworkItem> = emptyList(),
  val isScanningWifi: Boolean = false,
  val wifiError: String? = null,
  val wifiSearchQuery: String = "",
  val wifiSortBySignal: Boolean = true,
  val bleDevices: List<BleDeviceItem> = emptyList(),
  val isScanningBle: Boolean = false,
  val bleError: String? = null,
  val bleSearchQuery: String = "",
  val bleNamedOnly: Boolean = false,
  val isSavingWifi: Boolean = false,
  val snackbarMessage: String? = null,
  val esp32InoCode: String = "",
)

class Esp32ViewModel(application: Application) : AndroidViewModel(application) {

  private val networkInspector = AndroidNetworkInspector(application)
  private val preferences = Esp32Preferences(application)
  private val repository = Esp32Repository(application, networkInspector)

  private val _state = MutableStateFlow(Esp32UiState())

  val uiState: StateFlow<Esp32UiState> =
    combine(
        _state,
        preferences.recentHostsFlow,
      ) { state, recent ->
        state.copy(recentHosts = recent)
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = Esp32UiState(),
      )

  init {
    _state.update {
      it.copy(
        esp32InoCode = repository.loadBundledInoCode(),
        phoneNetworkInfo = networkInspector.getPhoneNetworkInfo(),
      )
    }

    viewModelScope.launch {
      val savedHost = preferences.lastHostFlow.first()
      _state.update { it.copy(hostInput = savedHost, activeHost = savedHost) }
      refreshPhoneNetwork()
    }

    viewModelScope.launch {
      networkInspector.wifiNetwork.collect {
        refreshPhoneNetwork()
      }
    }
  }

  fun refreshPhoneNetwork() {
    _state.update { it.copy(phoneNetworkInfo = networkInspector.getPhoneNetworkInfo()) }
  }

  fun updateHostInput(value: String) {
    _state.update { it.copy(hostInput = value) }
  }

  fun selectPresetHost(host: String) {
    _state.update { it.copy(hostInput = host) }
    connectAndSync(host)
  }

  fun connectAndSync(targetHost: String = _state.value.hostInput) {
    val cleanHost = repository.normalizeHost(targetHost)
    if (cleanHost.isBlank()) {
      _state.update { it.copy(snackbarMessage = "Lütfen geçerli bir ESP32 IP adresi girin.") }
      return
    }

    viewModelScope.launch {
      refreshPhoneNetwork()
      _state.update {
        it.copy(
          hostInput = cleanHost,
          activeHost = cleanHost,
          connectionState = ConnectionState.Connecting(cleanHost),
          wifiError = null,
          bleError = null,
        )
      }

      val statusResult = repository.fetchStatus(cleanHost)
      statusResult.fold(
        onSuccess = { status ->
          preferences.saveHost(cleanHost)
          _state.update {
            it.copy(
              connectionState = ConnectionState.Connected(cleanHost),
              esp32Status = status,
            )
          }
          // Bağlantı kurulunca Wi-Fi ve Bluetooth listelerini otomatik çek
          scanWifiFromEsp32(silentError = true)
          scanBleFromEsp32(silentError = true)
        },
        onFailure = { err ->
          _state.update {
            it.copy(
              connectionState =
                ConnectionState.Error(
                  err.message ?: "ESP32 ($cleanHost) adresine ulaşılamadı."
                ),
            )
          }
        },
      )
    }
  }

  fun refreshStatusOnly() {
    val host = _state.value.activeHost
    viewModelScope.launch {
      refreshPhoneNetwork()
      _state.update { it.copy(connectionState = ConnectionState.Connecting(host)) }
      repository.fetchStatus(host).fold(
        onSuccess = { status ->
          _state.update {
            it.copy(
              connectionState = ConnectionState.Connected(host),
              esp32Status = status,
            )
          }
        },
        onFailure = { err ->
          _state.update {
            it.copy(
              connectionState = ConnectionState.Error(err.message ?: "Durum güncellenemedi."),
            )
          }
        },
      )
    }
  }

  fun discoverEsp32OnNetwork() {
    viewModelScope.launch {
      refreshPhoneNetwork()
      _state.update { it.copy(isDiscovering = true, discoveredDevices = emptyList()) }
      val found = repository.discoverEsp32(_state.value.hostInput)
      _state.update {
        it.copy(
          isDiscovering = false,
          discoveredDevices = found,
          snackbarMessage =
            if (found.isEmpty()) {
              "Ağda ESP32 bulunamadı. Telefonunuzun ESP32-WROOM-Net veya aynı Wi-Fi ağında olduğundan emin olun."
            } else {
              "${found.size} adet ESP32 cihazı bulundu!"
            },
        )
      }
      if (found.size == 1) {
        val device = found.first()
        preferences.saveHost(device.reachIp)
        _state.update {
          it.copy(
            hostInput = device.reachIp,
            activeHost = device.reachIp,
            esp32Status = device.status,
            connectionState = ConnectionState.Connected(device.reachIp),
          )
        }
        scanWifiFromEsp32(silentError = true)
        scanBleFromEsp32(silentError = true)
      }
    }
  }

  fun scanWifiFromEsp32(silentError: Boolean = false) {
    val host = _state.value.activeHost
    viewModelScope.launch {
      _state.update { it.copy(isScanningWifi = true, wifiError = null) }
      repository.scanWifi(host).fold(
        onSuccess = { result ->
          val sorted =
            if (_state.value.wifiSortBySignal) {
              result.networks.sortedByDescending { it.rssi }
            } else {
              result.networks.sortedBy { it.ssid.lowercase() }
            }
          _state.update { current ->
            val updatedStatus =
              current.esp32Status?.copy(
                savedSsid = result.savedSsid,
                staConnected = result.staConnected,
                staIp = result.staIp,
              )
            current.copy(
              isScanningWifi = false,
              wifiNetworks = sorted,
              esp32Status = updatedStatus,
              wifiError = null,
            )
          }
        },
        onFailure = { err ->
          val msg = err.message ?: "Wi-Fi ağları ESP32'den çekilemedi."
          _state.update {
            it.copy(
              isScanningWifi = false,
              wifiError = msg,
              snackbarMessage = if (silentError) null else msg,
            )
          }
        },
      )
    }
  }

  fun scanBleFromEsp32(silentError: Boolean = false) {
    val host = _state.value.activeHost
    viewModelScope.launch {
      _state.update { it.copy(isScanningBle = true, bleError = null) }
      repository.scanBle(host).fold(
        onSuccess = { result ->
          _state.update {
            it.copy(
              isScanningBle = false,
              bleDevices = result.devices,
              bleError = null,
            )
          }
        },
        onFailure = { err ->
          val msg = err.message ?: "Bluetooth cihazları ESP32'den çekilemedi."
          _state.update {
            it.copy(
              isScanningBle = false,
              bleError = msg,
              snackbarMessage = if (silentError) null else msg,
            )
          }
        },
      )
    }
  }

  fun saveAndConnectWifi(ssid: String, password: String) {
    val host = _state.value.activeHost
    viewModelScope.launch {
      _state.update { it.copy(isSavingWifi = true) }
      repository.connectWifi(host, ssid, password).fold(
        onSuccess = { status ->
          _state.update {
            it.copy(
              isSavingWifi = false,
              esp32Status = status,
              snackbarMessage =
                if (status.staConnected) {
                  "${status.savedSsid} ağına bağlandı! Kayıtlı IP: ${status.staIp}"
                } else {
                  "$ssid kaydedildi ancak bağlantı kurulamadı. Şifreyi kontrol edin."
                },
            )
          }
          scanWifiFromEsp32(silentError = true)
        },
        onFailure = { err ->
          _state.update {
            it.copy(
              isSavingWifi = false,
              snackbarMessage = err.message ?: "Wi-Fi kaydedilirken hata oluştu.",
            )
          }
        },
      )
    }
  }

  fun forgetSavedWifi() {
    val host = _state.value.activeHost
    viewModelScope.launch {
      _state.update { it.copy(isSavingWifi = true) }
      repository.forgetWifi(host).fold(
        onSuccess = { status ->
          _state.update {
            it.copy(
              isSavingWifi = false,
              esp32Status = status,
              snackbarMessage = "Kayıtlı Wi-Fi bilgileri ESP32'den silindi.",
            )
          }
          scanWifiFromEsp32(silentError = true)
        },
        onFailure = { err ->
          _state.update {
            it.copy(
              isSavingWifi = false,
              snackbarMessage = err.message ?: "Kayıtlı Wi-Fi silinemedi.",
            )
          }
        },
      )
    }
  }

  fun updateWifiSearch(query: String) {
    _state.update { it.copy(wifiSearchQuery = query) }
  }

  fun toggleWifiSort() {
    _state.update { current ->
      val newSort = !current.wifiSortBySignal
      val sorted =
        if (newSort) {
          current.wifiNetworks.sortedByDescending { it.rssi }
        } else {
          current.wifiNetworks.sortedBy { it.ssid.lowercase() }
        }
      current.copy(wifiSortBySignal = newSort, wifiNetworks = sorted)
    }
  }

  fun updateBleSearch(query: String) {
    _state.update { it.copy(bleSearchQuery = query) }
  }

  fun toggleBleNamedOnly() {
    _state.update { it.copy(bleNamedOnly = !it.bleNamedOnly) }
  }

  fun showSnackbar(message: String) {
    _state.update { it.copy(snackbarMessage = message) }
  }

  fun clearSnackbar() {
    _state.update { it.copy(snackbarMessage = null) }
  }
}
