package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Sort
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material.icons.rounded.WifiOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.ConnectionState
import com.example.model.WifiNetworkItem
import com.example.ui.Esp32UiState
import com.example.ui.components.SignalStrengthBars
import com.example.ui.components.rssiToPercent
import com.example.ui.theme.MonoFontFamily

@Composable
fun WifiNetworksScreen(
  uiState: Esp32UiState,
  onScanWifi: () -> Unit,
  onSearchQueryChange: (String) -> Unit,
  onToggleSort: () -> Unit,
  onSaveAndConnectWifi: (ssid: String, password: String) -> Unit,
  onGoToDashboard: () -> Unit,
  modifier: Modifier = Modifier,
) {
  var selectedNetworkForConnect by remember { mutableStateOf<WifiNetworkItem?>(null) }

  val filteredNetworks =
    remember(uiState.wifiNetworks, uiState.wifiSearchQuery) {
      val q = uiState.wifiSearchQuery.trim()
      if (q.isBlank()) uiState.wifiNetworks
      else uiState.wifiNetworks.filter {
        it.ssid.contains(q, ignoreCase = true) || it.bssid.contains(q, ignoreCase = true)
      }
    }

  val isConnectedToEsp = uiState.connectionState is ConnectionState.Connected
  val savedSsid = uiState.esp32Status?.savedSsid.orEmpty()
  val staConnected = uiState.esp32Status?.staConnected == true
  val staIp = uiState.esp32Status?.staIp ?: "0.0.0.0"

  Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
    Column(modifier = Modifier.widthIn(max = 840.dp).fillMaxSize()) {
      // Sabit Kayıtlı Wi-Fi IP Banner + Tarama Kontrolü
      Column(
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        if (savedSsid.isNotBlank()) {
          Surface(
            color =
              if (staConnected) MaterialTheme.colorScheme.tertiaryContainer
              else MaterialTheme.colorScheme.surfaceContainer,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = "Kayıtlı Wi-Fi: $savedSsid",
                  style = MaterialTheme.typography.labelLarge,
                  color =
                    if (staConnected) MaterialTheme.colorScheme.onTertiaryContainer
                    else MaterialTheme.colorScheme.onSurface,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
                Text(
                  text = if (staConnected) "Kayıtlı Ağ IP: $staIp" else "Şu an bağlı değil",
                  style = MaterialTheme.typography.labelMedium.copy(fontFamily = MonoFontFamily),
                  color =
                    if (staConnected) MaterialTheme.colorScheme.tertiary
                    else MaterialTheme.colorScheme.onSurfaceVariant,
                )
              }
              if (staConnected) {
                Icon(
                  imageVector = Icons.Rounded.CheckCircle,
                  contentDescription = "Kayıtlı Wi-Fi bağlı",
                  tint = MaterialTheme.colorScheme.tertiary,
                )
              }
            }
          }
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          OutlinedTextField(
            value = uiState.wifiSearchQuery,
            onValueChange = onSearchQueryChange,
            placeholder = { Text("Wi-Fi adı veya BSSID ara...") },
            leadingIcon = {
              Icon(imageVector = Icons.Rounded.Search, contentDescription = "Ara")
            },
            singleLine = true,
            modifier = Modifier.weight(1f).testTag("wifi_search_input"),
          )

          FilledTonalIconButton(
            onClick = onToggleSort,
            modifier = Modifier.minimumInteractiveComponentSize().testTag("wifi_sort_button"),
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Rounded.Sort,
              contentDescription =
                if (uiState.wifiSortBySignal) "İsme göre sırala" else "Sinyale göre sırala",
            )
          }

          Button(
            onClick = onScanWifi,
            enabled = !uiState.isScanningWifi && isConnectedToEsp,
            modifier = Modifier.heightIn(min = 48.dp).testTag("scan_wifi_button"),
          ) {
            if (uiState.isScanningWifi) {
              CircularProgressIndicator(
                modifier = Modifier.size(18.dp),
                strokeWidth = 2.dp,
                color = MaterialTheme.colorScheme.onPrimary,
              )
            } else {
              Icon(
                imageVector = Icons.Rounded.Refresh,
                contentDescription = null,
                modifier = Modifier.size(18.dp),
              )
            }
            Spacer(modifier = Modifier.width(6.dp))
            Text(if (uiState.isScanningWifi) "Taranıyor" else "Tara")
          }
        }
      }

      if (!isConnectedToEsp) {
        EmptyStateCard(
          icon = Icons.Rounded.WifiOff,
          title = "Önce ESP32'ye Bağlanın",
          subtitle =
            "Çevredeki Wi-Fi ağlarını ESP32 üzerinden çekmek için Durum sekmesinden ESP32'ye bağlanın.",
          buttonText = "Durum & Bağlantıya Git",
          onAction = onGoToDashboard,
          testTag = "wifi_empty_goto_dashboard",
        )
      } else if (uiState.wifiError != null && filteredNetworks.isEmpty()) {
        EmptyStateCard(
          icon = Icons.Rounded.WifiOff,
          title = "Wi-Fi Taraması Alınamadı",
          subtitle = uiState.wifiError,
          buttonText = "Tekrar Dene",
          onAction = onScanWifi,
          testTag = "wifi_retry_button",
        )
      } else if (filteredNetworks.isEmpty() && !uiState.isScanningWifi) {
        EmptyStateCard(
          icon = Icons.Rounded.Wifi,
          title = "Wi-Fi Ağı Bulunamadı",
          subtitle = "ESP32 çevresinde ağları taramak için Tara butonuna dokunun.",
          buttonText = "Wi-Fi Ağlarını Tara",
          onAction = onScanWifi,
          testTag = "wifi_empty_scan_button",
        )
      } else {
        LazyColumn(
          modifier = Modifier.fillMaxSize(),
          contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          item {
            Text(
              text =
                "ESP32 Tarafından Bulunan ${filteredNetworks.size} Wi-Fi Ağı (Kaydetmek için dokunun)",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }

          items(
            items = filteredNetworks,
            key = { "${it.bssid}_${it.ssid}_${it.channel}" },
          ) { net ->
            val isSavedNetwork =
              net.isSaved || (savedSsid.isNotBlank() && net.ssid == savedSsid)
            WifiNetworkCard(
              network = net,
              isSavedNetwork = isSavedNetwork,
              savedWifiIp = if (isSavedNetwork && staConnected) staIp else null,
              onClick = { selectedNetworkForConnect = net },
            )
          }
        }
      }
    }
  }

  selectedNetworkForConnect?.let { target ->
    ConnectWifiDialog(
      network = target,
      isSaving = uiState.isSavingWifi,
      onDismiss = { selectedNetworkForConnect = null },
      onConfirm = { password ->
        onSaveAndConnectWifi(target.ssid, password)
        selectedNetworkForConnect = null
      },
    )
  }
}

@Composable
private fun WifiNetworkCard(
  network: WifiNetworkItem,
  isSavedNetwork: Boolean,
  savedWifiIp: String?,
  onClick: () -> Unit,
) {
  val accentColor =
    if (isSavedNetwork) MaterialTheme.colorScheme.tertiary
    else MaterialTheme.colorScheme.primary

  Card(
    onClick = onClick,
    shape = RoundedCornerShape(16.dp),
    colors =
      CardDefaults.cardColors(
        containerColor =
          if (isSavedNetwork) {
            MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.32f)
          } else {
            MaterialTheme.colorScheme.surface
          },
      ),
    border =
      BorderStroke(
        width = if (isSavedNetwork) 1.5.dp else 1.dp,
        color =
          if (isSavedNetwork) MaterialTheme.colorScheme.tertiary
          else MaterialTheme.colorScheme.outlineVariant,
      ),
    modifier = Modifier.fillMaxWidth().testTag("wifi_card_${network.bssid}"),
  ) {
    Row(
      modifier = Modifier.padding(14.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.width(44.dp),
      ) {
        SignalStrengthBars(rssi = network.rssi, activeColor = accentColor)
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = "%${rssiToPercent(network.rssi)}",
          style = MaterialTheme.typography.labelSmall,
          color = accentColor,
        )
      }

      Spacer(modifier = Modifier.width(12.dp))

      Column(modifier = Modifier.weight(1f)) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          Text(
            text = network.ssid.ifBlank { "(Gizli Ağ)" },
            style = MaterialTheme.typography.titleMedium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f, fill = false),
          )
          if (isSavedNetwork) {
            Surface(
              color = MaterialTheme.colorScheme.tertiary,
              contentColor = MaterialTheme.colorScheme.onTertiary,
              shape = RoundedCornerShape(6.dp),
            ) {
              Text(
                text = "Kayıtlı",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(4.dp))

        Text(
          text = "BSSID: ${network.bssid} • Kanal ${network.channel} • ${network.rssi} dBm",
          style = MaterialTheme.typography.bodySmall.copy(fontFamily = MonoFontFamily),
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )

        if (savedWifiIp != null) {
          Spacer(modifier = Modifier.height(6.dp))
          Surface(
            color = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.14f),
            shape = RoundedCornerShape(8.dp),
          ) {
            Text(
              text = "Kayıtlı Wi-Fi IP: $savedWifiIp",
              style = MaterialTheme.typography.labelMedium.copy(fontFamily = MonoFontFamily),
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.tertiary,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            )
          }
        }
      }

      Spacer(modifier = Modifier.width(8.dp))

      Column(horizontalAlignment = Alignment.End) {
        Icon(
          imageVector = if (network.isOpen) Icons.Rounded.LockOpen else Icons.Rounded.Lock,
          contentDescription = network.encryption,
          tint =
            if (network.isOpen) MaterialTheme.colorScheme.tertiary
            else MaterialTheme.colorScheme.onSurfaceVariant,
          modifier = Modifier.size(18.dp),
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = network.encryption,
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }
    }
  }
}

@Composable
private fun ConnectWifiDialog(
  network: WifiNetworkItem,
  isSaving: Boolean,
  onDismiss: () -> Unit,
  onConfirm: (String) -> Unit,
) {
  var password by remember { mutableStateOf("") }
  var showPassword by remember { mutableStateOf(false) }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Text(
        text = "ESP32'yi Wi-Fi Ağına Kaydet",
        style = MaterialTheme.typography.titleLarge,
      )
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
          text = "Ağ: ${network.ssid.ifBlank { "(Gizli Ağ)" }}",
          style = MaterialTheme.typography.titleMedium,
        )
        Text(
          text =
            "ESP32 bu Wi-Fi bilgilerini hafızasına kaydedip bağlanacak ve aldığı IP adresini ana ekranda gösterecektir.",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        if (!network.isOpen) {
          OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Wi-Fi Şifresi") },
            singleLine = true,
            visualTransformation =
              if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
            trailingIcon = {
              IconButton(
                onClick = { showPassword = !showPassword },
                modifier = Modifier.minimumInteractiveComponentSize(),
              ) {
                Icon(
                  imageVector =
                    if (showPassword) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                  contentDescription = if (showPassword) "Şifreyi gizle" else "Şifreyi göster",
                )
              }
            },
            modifier = Modifier.fillMaxWidth().testTag("wifi_password_input"),
          )
        }
      }
    },
    confirmButton = {
      Button(
        onClick = { onConfirm(password) },
        enabled = !isSaving && network.ssid.isNotBlank(),
        modifier = Modifier.testTag("confirm_save_wifi_button"),
      ) {
        Text("Kaydet ve Bağlan")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("İptal")
      }
    },
  )
}

@Composable
fun EmptyStateCard(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  title: String,
  subtitle: String,
  buttonText: String,
  onAction: () -> Unit,
  testTag: String,
) {
  Box(
    modifier = Modifier.fillMaxSize().padding(24.dp),
    contentAlignment = Alignment.Center,
  ) {
    Card(
      shape = RoundedCornerShape(22.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
      modifier = Modifier.fillMaxWidth(),
    ) {
      Column(
        modifier = Modifier.padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        Surface(
          color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
          shape = RoundedCornerShape(16.dp),
          modifier = Modifier.size(64.dp),
        ) {
          Box(contentAlignment = Alignment.Center) {
            Icon(
              imageVector = icon,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.primary,
              modifier = Modifier.size(32.dp),
            )
          }
        }
        Text(
          text = title,
          style = MaterialTheme.typography.titleLarge,
        )
        Text(
          text = subtitle,
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Button(
          onClick = onAction,
          modifier = Modifier.heightIn(min = 48.dp).testTag(testTag),
        ) {
          Text(buttonText)
        }
      }
    }
  }
}
