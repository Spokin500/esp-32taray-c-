package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bluetooth
import androidx.compose.material.icons.rounded.BluetoothDisabled
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.BleDeviceItem
import com.example.model.ConnectionState
import com.example.ui.Esp32UiState
import com.example.ui.components.SignalStrengthBars
import com.example.ui.components.rssiProximityLabel
import com.example.ui.theme.MonoFontFamily

@Composable
fun BluetoothDevicesScreen(
  uiState: Esp32UiState,
  onScanBle: () -> Unit,
  onSearchQueryChange: (String) -> Unit,
  onToggleNamedOnly: () -> Unit,
  onGoToDashboard: () -> Unit,
  onShowMessage: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  val clipboard = LocalClipboardManager.current
  val isConnectedToEsp = uiState.connectionState is ConnectionState.Connected

  val filteredDevices =
    remember(uiState.bleDevices, uiState.bleSearchQuery, uiState.bleNamedOnly) {
      val q = uiState.bleSearchQuery.trim()
      uiState.bleDevices.filter { dev ->
        val matchesNameFilter = !uiState.bleNamedOnly || dev.hasName
        val matchesQuery =
          q.isBlank() ||
            dev.name.contains(q, ignoreCase = true) ||
            dev.mac.contains(q, ignoreCase = true) ||
            dev.serviceUuid.contains(q, ignoreCase = true)
        matchesNameFilter && matchesQuery
      }
    }

  Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
    Column(modifier = Modifier.widthIn(max = 840.dp).fillMaxSize()) {
      Column(
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          OutlinedTextField(
            value = uiState.bleSearchQuery,
            onValueChange = onSearchQueryChange,
            placeholder = { Text("Cihaz adı veya MAC ara...") },
            leadingIcon = {
              Icon(imageVector = Icons.Rounded.Search, contentDescription = "Ara")
            },
            singleLine = true,
            modifier = Modifier.weight(1f).testTag("ble_search_input"),
          )

          Button(
            onClick = onScanBle,
            enabled = !uiState.isScanningBle && isConnectedToEsp,
            colors =
              ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.secondary,
                contentColor = MaterialTheme.colorScheme.onSecondary,
              ),
            modifier = Modifier.heightIn(min = 48.dp).testTag("scan_ble_button"),
          ) {
            if (uiState.isScanningBle) {
              CircularProgressIndicator(
                modifier = Modifier.size(18.dp),
                strokeWidth = 2.dp,
                color = MaterialTheme.colorScheme.onSecondary,
              )
            } else {
              Icon(
                imageVector = Icons.Rounded.Refresh,
                contentDescription = null,
                modifier = Modifier.size(18.dp),
              )
            }
            Spacer(modifier = Modifier.width(6.dp))
            Text(if (uiState.isScanningBle) "Taranıyor" else "BLE Tara")
          }
        }

        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          FilterChip(
            selected = uiState.bleNamedOnly,
            onClick = onToggleNamedOnly,
            label = { Text("Yalnızca İsimli Cihazlar") },
            modifier = Modifier.testTag("ble_named_only_chip"),
          )
          if (isConnectedToEsp) {
            Text(
              text = "Toplam ${filteredDevices.size} cihaz",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        }
      }

      if (!isConnectedToEsp) {
        EmptyStateCard(
          icon = Icons.Rounded.BluetoothDisabled,
          title = "Önce ESP32'ye Bağlanın",
          subtitle =
            "Çevredeki Bluetooth (BLE) cihazlarını ESP32 üzerinden çekmek için Durum sekmesinden ESP32'ye bağlanın.",
          buttonText = "Durum & Bağlantıya Git",
          onAction = onGoToDashboard,
          testTag = "ble_empty_goto_dashboard",
        )
      } else if (uiState.bleError != null && filteredDevices.isEmpty()) {
        EmptyStateCard(
          icon = Icons.Rounded.BluetoothDisabled,
          title = "Bluetooth Taraması Alınamadı",
          subtitle = uiState.bleError,
          buttonText = "Tekrar Dene",
          onAction = onScanBle,
          testTag = "ble_retry_button",
        )
      } else if (filteredDevices.isEmpty() && !uiState.isScanningBle) {
        EmptyStateCard(
          icon = Icons.Rounded.Bluetooth,
          title = "Bluetooth Cihazı Bulunamadı",
          subtitle =
            "ESP32'nin 3 saniyelik BLE taramasını başlatmak için BLE Tara butonuna dokunun.",
          buttonText = "Bluetooth Cihazlarını Tara",
          onAction = onScanBle,
          testTag = "ble_empty_scan_button",
        )
      } else {
        LazyColumn(
          modifier = Modifier.fillMaxSize(),
          contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          items(
            items = filteredDevices,
            key = { it.mac },
          ) { device ->
            BleDeviceCard(
              device = device,
              onCopyMac = {
                clipboard.setText(AnnotatedString(device.mac))
                onShowMessage("MAC adresi kopyalandı: ${device.mac}")
              },
            )
          }
        }
      }
    }
  }
}

@Composable
private fun BleDeviceCard(
  device: BleDeviceItem,
  onCopyMac: () -> Unit,
) {
  val bleColor = MaterialTheme.colorScheme.secondary

  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    modifier = Modifier.fillMaxWidth().testTag("ble_card_${device.mac}"),
  ) {
    Row(
      modifier = Modifier.padding(14.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.width(44.dp),
      ) {
        SignalStrengthBars(rssi = device.rssi, activeColor = bleColor)
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = "${device.rssi}",
          style = MaterialTheme.typography.labelSmall,
          color = bleColor,
        )
      }

      Spacer(modifier = Modifier.width(12.dp))

      Column(modifier = Modifier.weight(1f)) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          Text(
            text = device.name.ifBlank { "İsimsiz BLE Cihazı" },
            style = MaterialTheme.typography.titleMedium,
            color =
              if (device.hasName) MaterialTheme.colorScheme.onSurface
              else MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f, fill = false),
          )
        }

        Spacer(modifier = Modifier.height(3.dp))

        Text(
          text = "MAC: ${device.mac} • ${device.rssi} dBm",
          style = MaterialTheme.typography.bodySmall.copy(fontFamily = MonoFontFamily),
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Spacer(modifier = Modifier.height(6.dp))

        Row(
          horizontalArrangement = Arrangement.spacedBy(6.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Surface(
            color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.7f),
            shape = RoundedCornerShape(6.dp),
          ) {
            Text(
              text = rssiProximityLabel(device.rssi),
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.SemiBold,
              color = MaterialTheme.colorScheme.onSecondaryContainer,
              modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp),
            )
          }

          if (device.serviceUuid.isNotBlank()) {
            Surface(
              color = MaterialTheme.colorScheme.surfaceContainer,
              shape = RoundedCornerShape(6.dp),
            ) {
              Text(
                text = "UUID: ${device.serviceUuid.take(8)}...",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp),
              )
            }
          }
        }
      }

      IconButton(
        onClick = onCopyMac,
        modifier = Modifier.minimumInteractiveComponentSize().testTag("copy_ble_mac_${device.mac}"),
      ) {
        Icon(
          imageVector = Icons.Rounded.ContentCopy,
          contentDescription = "MAC adresini kopyala",
          tint = MaterialTheme.colorScheme.onSurfaceVariant,
          modifier = Modifier.size(18.dp),
        )
      }
    }
  }
}
