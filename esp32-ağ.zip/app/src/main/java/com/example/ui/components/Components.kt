package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.ui.theme.MonoFontFamily

@Composable
fun SignalStrengthBars(
  rssi: Int,
  activeColor: Color,
  modifier: Modifier = Modifier,
) {
  val bars = rssiToBars(rssi)
  val inactiveColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)

  Canvas(modifier = modifier.size(width = 24.dp, height = 18.dp)) {
    val barCount = 4
    val spacing = size.width * 0.12f
    val totalSpacing = spacing * (barCount - 1)
    val barWidth = (size.width - totalSpacing) / barCount

    for (i in 0 until barCount) {
      val heightFraction = (i + 1) / barCount.toFloat()
      val barHeight = size.height * heightFraction
      val x = i * (barWidth + spacing)
      val y = size.height - barHeight
      drawRoundRect(
        color = if (i < bars) activeColor else inactiveColor,
        topLeft = Offset(x, y),
        size = Size(barWidth, barHeight),
        cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx()),
      )
    }
  }
}

@Composable
fun StatusPill(
  text: String,
  dotColor: Color,
  containerColor: Color,
  contentColor: Color,
  modifier: Modifier = Modifier,
) {
  Surface(
    color = containerColor,
    contentColor = contentColor,
    shape = RoundedCornerShape(50),
    modifier = modifier,
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
    ) {
      Box(
        modifier =
          Modifier.size(8.dp).clip(CircleShape).background(dotColor)
      )
      Spacer(modifier = Modifier.width(6.dp))
      Text(
        text = text,
        style = MaterialTheme.typography.labelMedium,
        fontWeight = FontWeight.SemiBold,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )
    }
  }
}

@Composable
fun IpLocationRow(
  label: String,
  whereText: String,
  ipValue: String,
  accentColor: Color,
  onCopy: (() -> Unit)? = null,
  testTag: String,
) {
  Surface(
    color = MaterialTheme.colorScheme.surfaceContainer,
    shape = RoundedCornerShape(14.dp),
    modifier = Modifier.fillMaxWidth(),
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
      modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
    ) {
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = label,
          style = MaterialTheme.typography.labelLarge,
          color = MaterialTheme.colorScheme.onSurface,
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = whereText,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }
      Spacer(modifier = Modifier.width(8.dp))
      Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
          text = ipValue,
          style = MaterialTheme.typography.titleMedium.copy(fontFamily = MonoFontFamily),
          fontWeight = FontWeight.Bold,
          color = accentColor,
        )
        if (onCopy != null && ipValue != "0.0.0.0" && ipValue != "Yok" && ipValue != "-") {
          IconButton(
            onClick = onCopy,
            modifier = Modifier.minimumInteractiveComponentSize().testTag(testTag),
          ) {
            Icon(
              imageVector = Icons.Rounded.ContentCopy,
              contentDescription = "$label IP adresini kopyala",
              tint = MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.size(18.dp),
            )
          }
        }
      }
    }
  }
}

fun rssiToBars(rssi: Int): Int =
  when {
    rssi >= -55 -> 4
    rssi >= -68 -> 3
    rssi >= -80 -> 2
    rssi > -95 -> 1
    else -> 0
  }

fun rssiToPercent(rssi: Int): Int = ((rssi + 100) * 2).coerceIn(0, 100)

fun rssiProximityLabel(rssi: Int): String =
  when {
    rssi >= -55 -> "Çok Yakın"
    rssi >= -70 -> "Yakın"
    rssi >= -84 -> "Orta Mesafe"
    else -> "Uzak"
  }
