package com.example.model

data class Esp32Status(
  val board: String,
  val chipModel: String,
  val cpuMhz: Int,
  val freeHeapBytes: Long,
  val uptimeSec: Long,
  val macAddress: String,
  val apSsid: String,
  val apIp: String,
  val apClients: Int,
  val savedSsid: String,
  val staConnected: Boolean,
  val staStatusText: String,
  val staIp: String,
  val staGateway: String,
  val staSubnet: String,
  val staDns: String,
  val staRssi: Int,
  val mdnsHost: String,
)

data class WifiNetworkItem(
  val ssid: String,
  val bssid: String,
  val rssi: Int,
  val channel: Int,
  val encryption: String,
  val isOpen: Boolean,
  val isSaved: Boolean,
)

data class WifiScanResult(
  val count: Int,
  val savedSsid: String,
  val staConnected: Boolean,
  val staIp: String,
  val networks: List<WifiNetworkItem>,
)

data class BleDeviceItem(
  val name: String,
  val mac: String,
  val rssi: Int,
  val hasName: Boolean,
  val serviceUuid: String,
  val txPower: Int,
  val hasManufacturerData: Boolean,
)

data class BleScanResult(
  val count: Int,
  val scanDurationSec: Int,
  val devices: List<BleDeviceItem>,
)

data class PhoneNetworkInfo(
  val localIp: String,
  val gatewayIp: String,
  val subnetMask: String,
  val transportLabel: String,
  val isWifiConnected: Boolean,
)

data class DiscoveredEsp32(
  val reachIp: String,
  val status: Esp32Status,
)

sealed class ConnectionState {
  data object Disconnected : ConnectionState()
  data class Connecting(val host: String) : ConnectionState()
  data class Connected(val host: String) : ConnectionState()
  data class Error(val message: String) : ConnectionState()
}
