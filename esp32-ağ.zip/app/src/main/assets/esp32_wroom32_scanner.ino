/*
 * ============================================================================
 *  ESP32-WROOM-32 DevKit V1 (Klon Kart Uyumlu) - Wi-Fi & Bluetooth Tarayıcı
 * ============================================================================
 *  Özellikler:
 *   - Çift Mod (WIFI_AP_STA): Her zaman "ESP32-WROOM-Net" (192.168.4.1)
 *     erişim noktası açık kalır + kayıtlı Wi-Fi ağına (STA) otomatik bağlanır.
 *   - Kayıtlı Wi-Fi bilgilerini kalıcı hafızada (NVS / Preferences) saklar.
 *   - Kayıtlı Wi-Fi IP adresini, Ağ Geçidi, Alt Ağ, DNS ve RSSI bilgilerini
 *     JSON API (/api/status) üzerinden Android uygulamasına iletir.
 *   - Çevredeki Wi-Fi ağlarını tarar (/api/wifi).
 *   - Çevredeki Bluetooth Low Energy (BLE) cihazlarını tarar (/api/ble).
 *   - mDNS (esp32net.local) ve UDP Keşif (Port 4210) ile uygulama içinden
 *     IP adresi otomatik bulunur.
 *
 *  KLON KART İÇİN ARDUINO IDE AYARLARI:
 *   - Kart (Board): Mutlaka "ESP32 Dev Module" seçin!
 *     (NOT: "DOIT ESP32 DEVKIT V1" seçilirse Partition Scheme menüsü gizlenir
 *      ve "Sketch too big / 1310720 bytes" hatası alırsınız.)
 *   - Partition Scheme: "Huge APP (3MB No OTA/1MB SPIFFS)"  <-- ÇOK ÖNEMLİ!
 *     (Wi-Fi + BLE birlikte varsayılan 1.2MB alana sığmaz, Huge APP seçin.)
 *   - Upload Speed: "115200" (Klon CH340/CP2102 kartlarda en kararlı hız)
 *   - Sürücü: Bilgisayarınızda port görünmezse CH340 veya CP2102 sürücüsü kurun.
 *   - Yükleme İpucu: "Connecting........" yazarken karttaki BOOT tuşuna 2 sn basın.
 * ============================================================================
 */

#include <WiFi.h>
#include <WebServer.h>
#include <ESPmDNS.h>
#include <WiFiUdp.h>
#include <Preferences.h>
#include <BLEDevice.h>
#include <BLEUtils.h>
#include <BLEScan.h>
#include <BLEAdvertisedDevice.h>

// Klon DevKit V1 dahili LED pini (genelde GPIO 2)
static const int LED_PIN = 2;

// ESP32'nin kendi oluşturacağı Erişim Noktası (SoftAP) bilgileri
static const char* AP_SSID = "ESP32-WROOM-Net";
static const char* AP_PASS = "12345678";
static const char* MDNS_HOST = "esp32net";
static const uint16_t UDP_DISCOVER_PORT = 4210;

WebServer server(80);
WiFiUDP udp;
Preferences prefs;
BLEScan* pBLEScan = nullptr;

String savedSsid = "";
String savedPass = "";

// JSON içinde özel karakterlerin bozulmasını önler
String escapeJson(const String& input) {
  String out;
  out.reserve(input.length() + 8);
  for (unsigned int i = 0; i < input.length(); i++) {
    char c = input.charAt(i);
    if (c == '\"') out += "\\\"";
    else if (c == '\\') out += "\\\\";
    else if (c == '\b') out += "\\b";
    else if (c == '\f') out += "\\f";
    else if (c == '\n') out += "\\n";
    else if (c == '\r') out += "\\r";
    else if (c == '\t') out += "\\t";
    else if ((uint8_t)c >= 0x20) out += c;
  }
  return out;
}

String getEncryptionName(wifi_auth_mode_t authMode) {
  switch (authMode) {
    case WIFI_AUTH_OPEN: return "Açık";
    case WIFI_AUTH_WEP: return "WEP";
    case WIFI_AUTH_WPA_PSK: return "WPA-PSK";
    case WIFI_AUTH_WPA2_PSK: return "WPA2-PSK";
    case WIFI_AUTH_WPA_WPA2_PSK: return "WPA/WPA2";
    case WIFI_AUTH_WPA2_ENTERPRISE: return "WPA2-Enterprise";
#ifdef WIFI_AUTH_WPA3_PSK
    case WIFI_AUTH_WPA3_PSK: return "WPA3-PSK";
#endif
#ifdef WIFI_AUTH_WPA2_WPA3_PSK
    case WIFI_AUTH_WPA2_WPA3_PSK: return "WPA2/WPA3";
#endif
    default: return "Şifreli";
  }
}

void blinkLed(int times = 1, int ms = 60) {
  for (int i = 0; i < times; i++) {
    digitalWrite(LED_PIN, HIGH);
    delay(ms);
    digitalWrite(LED_PIN, LOW);
    if (i < times - 1) delay(ms);
  }
}

String buildStatusJson() {
  bool staConnected = (WiFi.status() == WL_CONNECTED);
  String staIp = staConnected ? WiFi.localIP().toString() : "0.0.0.0";
  String staGw = staConnected ? WiFi.gatewayIP().toString() : "0.0.0.0";
  String staSubnet = staConnected ? WiFi.subnetMask().toString() : "0.0.0.0";
  String staDns = staConnected ? WiFi.dnsIP().toString() : "0.0.0.0";
  int staRssi = staConnected ? WiFi.RSSI() : 0;

  String activeSsid = savedSsid;
  if (staConnected && WiFi.SSID().length() > 0) {
    activeSsid = WiFi.SSID();
  }

  String statusText = "Kayıtlı Wi-Fi Yok";
  if (staConnected) {
    statusText = "Bağlı";
  } else if (savedSsid.length() > 0) {
    statusText = "Kayıtlı (Bağlanılamadı)";
  }

  String json = "{";
  json += "\"board\":\"ESP32-WROOM-32 DevKit V1\",";
  json += "\"chip_model\":\"" + escapeJson(String(ESP.getChipModel())) + "\",";
  json += "\"cpu_mhz\":" + String(ESP.getCpuFreqMHz()) + ",";
  json += "\"free_heap\":" + String(ESP.getFreeHeap()) + ",";
  json += "\"uptime_sec\":" + String(millis() / 1000UL) + ",";
  json += "\"mac\":\"" + escapeJson(WiFi.macAddress()) + "\",";
  json += "\"ap_ssid\":\"" + escapeJson(String(AP_SSID)) + "\",";
  json += "\"ap_ip\":\"" + WiFi.softAPIP().toString() + "\",";
  json += "\"ap_clients\":" + String(WiFi.softAPgetStationNum()) + ",";
  json += "\"saved_ssid\":\"" + escapeJson(activeSsid) + "\",";
  json += "\"sta_connected\":" + String(staConnected ? "true" : "false") + ",";
  json += "\"sta_status_text\":\"" + escapeJson(statusText) + "\",";
  json += "\"sta_ip\":\"" + staIp + "\",";
  json += "\"sta_gateway\":\"" + staGw + "\",";
  json += "\"sta_subnet\":\"" + staSubnet + "\",";
  json += "\"sta_dns\":\"" + staDns + "\",";
  json += "\"sta_rssi\":" + String(staRssi) + ",";
  json += "\"mdns\":\"" + String(MDNS_HOST) + ".local\"";
  json += "}";
  return json;
}

void connectToSavedWifi(unsigned long timeoutMs = 10000) {
  if (savedSsid.length() == 0) {
    Serial.println("[WiFi] Kayıtlı SSID bulunamadı. Sadece AP aktif.");
    return;
  }

  Serial.print("[WiFi] Kayıtlı ağa bağlanılıyor: ");
  Serial.println(savedSsid);

  WiFi.disconnect(false);
  delay(100);
  if (savedPass.length() > 0) {
    WiFi.begin(savedSsid.c_str(), savedPass.c_str());
  } else {
    WiFi.begin(savedSsid.c_str());
  }

  unsigned long start = millis();
  while (WiFi.status() != WL_CONNECTED && (millis() - start) < timeoutMs) {
    delay(250);
    Serial.print(".");
  }
  Serial.println();

  if (WiFi.status() == WL_CONNECTED) {
    Serial.print("[WiFi] Bağlandı! Kayıtlı Wi-Fi IP: ");
    Serial.println(WiFi.localIP());
    blinkLed(3, 80);
  } else {
    Serial.println("[WiFi] Kayıtlı ağa şu an bağlanılamadı (AP erişilebilir).");
  }
}

void handleRoot() {
  String html = "<!DOCTYPE html><html><head><meta charset='utf-8'>"
                "<title>ESP32-WROOM-32 Scanner</title></head>"
                "<body style='font-family:monospace;background:#0d1b2a;color:#e0fbfc;padding:24px'>"
                "<h2>ESP32-WROOM-32 Ağ Tarayıcı Aktif</h2>"
                "<p>Kayıtlı Wi-Fi: <b>" + escapeJson(savedSsid) + "</b></p>"
                "<p>Kayıtlı Wi-Fi IP: <b>" + (WiFi.status() == WL_CONNECTED ? WiFi.localIP().toString() : "Bağlı değil") + "</b></p>"
                "<p>AP IP: <b>" + WiFi.softAPIP().toString() + "</b></p>"
                "<p>API Uçları: /api/status | /api/wifi | /api/ble</p>"
                "</body></html>";
  server.send(200, "text/html", html);
}

void handleStatus() {
  blinkLed(1, 35);
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.send(200, "application/json", buildStatusJson());
}

void handleWifiScan() {
  blinkLed(1, 50);
  Serial.println("[WiFi] Ağlar taranıyor...");

  int n = WiFi.scanNetworks(false, true);
  bool staConnected = (WiFi.status() == WL_CONNECTED);
  String staIp = staConnected ? WiFi.localIP().toString() : "0.0.0.0";

  String json = "{";
  json += "\"count\":" + String(n < 0 ? 0 : n) + ",";
  json += "\"saved_ssid\":\"" + escapeJson(savedSsid) + "\",";
  json += "\"sta_connected\":" + String(staConnected ? "true" : "false") + ",";
  json += "\"sta_ip\":\"" + staIp + "\",";
  json += "\"networks\":[";

  for (int i = 0; i < n; i++) {
    if (i > 0) json += ",";
    String ssid = WiFi.SSID(i);
    bool isSaved = (savedSsid.length() > 0 && ssid == savedSsid);
    bool isOpen = (WiFi.encryptionType(i) == WIFI_AUTH_OPEN);

    json += "{";
    json += "\"ssid\":\"" + escapeJson(ssid) + "\",";
    json += "\"bssid\":\"" + escapeJson(WiFi.BSSIDstr(i)) + "\",";
    json += "\"rssi\":" + String(WiFi.RSSI(i)) + ",";
    json += "\"channel\":" + String(WiFi.channel(i)) + ",";
    json += "\"encryption\":\"" + escapeJson(getEncryptionName(WiFi.encryptionType(i))) + "\",";
    json += "\"is_open\":" + String(isOpen ? "true" : "false") + ",";
    json += "\"is_saved\":" + String(isSaved ? "true" : "false");
    json += "}";
  }

  json += "]}";
  WiFi.scanDelete();

  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.send(200, "application/json", json);
}

void handleBleScan() {
  blinkLed(2, 40);
  Serial.println("[BLE] Bluetooth (BLE) cihazları taranıyor...");

  const uint32_t scanSeconds = 3;
  int count = 0;

#if defined(ESP_ARDUINO_VERSION_MAJOR) && (ESP_ARDUINO_VERSION_MAJOR >= 3)
  BLEScanResults* foundDevices = pBLEScan->start(scanSeconds, false);
  count = foundDevices ? foundDevices->getCount() : 0;
#else
  BLEScanResults resultsVal = pBLEScan->start(scanSeconds, false);
  BLEScanResults* foundDevices = &resultsVal;
  count = foundDevices->getCount();
#endif

  String json = "{";
  json += "\"count\":" + String(count) + ",";
  json += "\"scan_duration_sec\":" + String(scanSeconds) + ",";
  json += "\"devices\":[";

  for (int i = 0; i < count; i++) {
    if (i > 0) json += ",";
    BLEAdvertisedDevice dev = foundDevices->getDevice(i);
    String name = dev.haveName() ? String(dev.getName().c_str()) : "";
    String mac = String(dev.getAddress().toString().c_str());
    int rssi = dev.getRSSI();
    String serviceUuid = dev.haveServiceUUID() ? String(dev.getServiceUUID().toString().c_str()) : "";
    int txPower = dev.haveTXPower() ? dev.getTXPower() : -999;
    bool hasMfg = dev.haveManufacturerData();

    json += "{";
    json += "\"name\":\"" + escapeJson(name) + "\",";
    json += "\"mac\":\"" + escapeJson(mac) + "\",";
    json += "\"rssi\":" + String(rssi) + ",";
    json += "\"has_name\":" + String(name.length() > 0 ? "true" : "false") + ",";
    json += "\"service_uuid\":\"" + escapeJson(serviceUuid) + "\",";
    json += "\"tx_power\":" + String(txPower) + ",";
    json += "\"has_manufacturer_data\":" + String(hasMfg ? "true" : "false");
    json += "}";
  }

  json += "]}";
  pBLEScan->clearResults();

  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.send(200, "application/json", json);
}

void handleWifiConnect() {
  if (!server.hasArg("ssid") || server.arg("ssid").length() == 0) {
    server.send(400, "application/json", "{\"error\":\"SSID boş olamaz\"}");
    return;
  }

  savedSsid = server.arg("ssid");
  savedPass = server.hasArg("password") ? server.arg("password") : "";

  prefs.putString("ssid", savedSsid);
  prefs.putString("pass", savedPass);

  connectToSavedWifi(10000);

  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.send(200, "application/json", buildStatusJson());
}

void handleWifiForget() {
  savedSsid = "";
  savedPass = "";
  prefs.remove("ssid");
  prefs.remove("pass");
  WiFi.disconnect(false, true);

  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.send(200, "application/json", buildStatusJson());
}

void handleUdpDiscovery() {
  int packetSize = udp.parsePacket();
  if (packetSize <= 0) return;

  char incoming[64];
  int len = udp.read(incoming, sizeof(incoming) - 1);
  if (len > 0) {
    incoming[len] = '\0';
    String msg = String(incoming);
    msg.trim();
    if (msg == "ESP32_DISCOVER") {
      String reply = buildStatusJson();
      udp.beginPacket(udp.remoteIP(), udp.remotePort());
      udp.print(reply);
      udp.endPacket();
    }
  }
}

void setup() {
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);

  Serial.begin(115200);
  delay(300);
  Serial.println();
  Serial.println("=== ESP32-WROOM-32 DevKit V1 Ağ Tarayıcı Başlatılıyor ===");

  // Kayıtlı Wi-Fi bilgilerini NVS hafızadan oku
  prefs.begin("wifi_cfg", false);
  savedSsid = prefs.getString("ssid", "");
  savedPass = prefs.getString("pass", "");

  // Çift mod: Hem AP açık kalsın hem kayıtlı Wi-Fi'ye bağlansın
  WiFi.mode(WIFI_AP_STA);
  WiFi.setSleep(false); // Klon kartlarda bağlantı kopmalarını azaltır

  bool apOk = WiFi.softAP(AP_SSID, AP_PASS);
  Serial.print("[AP] Durum: ");
  Serial.print(apOk ? "Hazır | SSID: " : "Hata | ");
  Serial.print(AP_SSID);
  Serial.print(" | AP IP: ");
  Serial.println(WiFi.softAPIP());

  // Kayıtlı Wi-Fi varsa bağlan
  connectToSavedWifi(10000);

  // mDNS başlat (http://esp32net.local)
  if (MDNS.begin(MDNS_HOST)) {
    MDNS.addService("http", "tcp", 80);
    Serial.println("[mDNS] http://esp32net.local aktif");
  }

  // UDP otomatik keşif dinleyicisi
  udp.begin(UDP_DISCOVER_PORT);
  Serial.printf("[UDP] Keşif portu dinleniyor: %d\n", UDP_DISCOVER_PORT);

  // BLE tarayıcısını hazırla
  BLEDevice::init("ESP32-WROOM-Scanner");
  pBLEScan = BLEDevice::getScan();
  pBLEScan->setActiveScan(true);
  pBLEScan->setInterval(100);
  pBLEScan->setWindow(99);

  // HTTP API rotaları
  server.on("/", HTTP_GET, handleRoot);
  server.on("/api/status", HTTP_GET, handleStatus);
  server.on("/api/wifi", HTTP_GET, handleWifiScan);
  server.on("/api/ble", HTTP_GET, handleBleScan);
  server.on("/api/wifi/connect", HTTP_POST, handleWifiConnect);
  server.on("/api/wifi/forget", HTTP_POST, handleWifiForget);
  server.begin();

  Serial.println("[HTTP] Web sunucusu Port 80 üzerinde hazır!");
  blinkLed(2, 100);
}

void loop() {
  server.handleClient();
  handleUdpDiscovery();
  delay(2);
}
