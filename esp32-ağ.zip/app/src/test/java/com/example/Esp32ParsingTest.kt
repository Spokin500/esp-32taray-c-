package com.example

import com.example.ui.components.rssiProximityLabel
import com.example.ui.components.rssiToBars
import com.example.ui.components.rssiToPercent
import org.junit.Assert.assertEquals
import org.junit.Test

class Esp32ParsingTest {

  @Test
  fun `rssi helpers map signal strengths as expected`() {
    assertEquals(4, rssiToBars(-50))
    assertEquals(3, rssiToBars(-65))
    assertEquals(2, rssiToBars(-75))
    assertEquals(1, rssiToBars(-90))
    assertEquals(100, rssiToPercent(-45))
    assertEquals(0, rssiToPercent(-105))
    assertEquals("Çok Yakın", rssiProximityLabel(-52))
    assertEquals("Yakın", rssiProximityLabel(-64))
    assertEquals("Orta Mesafe", rssiProximityLabel(-78))
    assertEquals("Uzak", rssiProximityLabel(-92))
  }
}
